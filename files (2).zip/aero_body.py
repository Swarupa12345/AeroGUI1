#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
aero_body.py  —  DRDL Aerospace AI Platform  —  3-D Geometry Generator
========================================================================
Generates a 3-D aerodynamic body (nose cone + cylindrical fuselage +
symmetric wing/tail fin panels, cruciform or conventional layout) purely
from geometric design parameters — independent of the XGBoost surrogate
model in predictor.py.

Public API
----------
_validate_positive(value, name) -> float
_deg2rad(deg) -> float
solve_unblunted_cone(length, radius, bluntness, tol=1e-6) -> (float, np.ndarray)
generate_nose(nose_length, nose_diameter, nose_bluntness) -> (X, Y, Z)
generate_body(body_length, body_diameter, nose_length) -> (X, Y, Z)
_biconvex_thickness(x, root_chord, tip_chord, root_th, tip_th) -> np.ndarray
generate_fin_panel(le, root_chord, tip_chord, semi_span, hinge_line,
                    root_th, tip_th, sweep, body_diameter, side="right")
                    -> (X, Y, Z)
plot_matplotlib(nose, body, fins, png_out, show=False, block=True) -> None
_make_plotly_mesh(X, Y, Z, name) -> go.Mesh3d
plot_plotly(nose, body, fins, html_out, stats) -> None
prompt_parameter(name, default, typ=float) -> Any
_fuselage_stats(nose_length, body_length, body_diameter) -> dict
_fin_stats(root_chord, tip_chord, semi_span, root_th, tip_th) -> dict
visualize_aero_body(params) -> None
_build_arg_parser() -> argparse.ArgumentParser
main() -> None

Dependencies
------------
Standard library + numpy + matplotlib (mandatory).
plotly (optional — detected at import time; falls back gracefully).
========================================================================
"""

import argparse
import math
import os
import sys
from typing import Any, Dict, List, Tuple

import numpy as np
import matplotlib
matplotlib.use('Agg' if '--no-show' in sys.argv else matplotlib.get_backend())
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401  (registers 3-D proj.)

try:
    import plotly.graph_objects as go
    from plotly.subplots import make_subplots
    _HAS_PLOTLY = True
except ImportError:
    _HAS_PLOTLY = False


# =========================================================
# DEFAULTS (match app.py DEFAULTS where the keys overlap)
# =========================================================
DEFAULTS = {
    'nose_len': 300.0, 'nose_diameter': None, 'nose_bluntness': 0.08,
    'body_len': 2700.0, 'body_diameter': None,
    'wing_le': 1500.0, 'root_chord': 200.0, 'tip_chord': 150.0,
    'semi_span': 1000.0, 'root_th': 20.0, 'tip_th': 5.0, 'wing_sweep': 2.86,
    'tail_le': 2870.0, 'root_chord1': 120.0, 'tip_chord1': 60.0,
    'semi_span1': 100.0, 'root_th1': 15.0, 'tip_th1': 5.0,
    'layout': 'cruciform',
}

_N_AXIAL = 40   # stations along nose/body axis
_N_THETA = 36   # revolution divisions
_N_SPAN = 20    # spanwise fin stations
_N_CHORD = 14   # chordwise fin stations


# =========================================================
# VALIDATION HELPERS
# =========================================================
def _validate_positive(value: float, name: str) -> float:
    """Return value as float; raise ValueError if it is not > 0."""
    v = float(value)
    if v <= 0.0:
        raise ValueError(f"'{name}' must be a positive number, got {v}")
    return v


def _deg2rad(deg: float) -> float:
    """Convert degrees to radians."""
    return float(deg) * math.pi / 180.0


# =========================================================
# NOSE-CONE BLUNTING SOLVER
# =========================================================
def solve_unblunted_cone(length: float, radius: float, bluntness: float,
                          tol: float = 1e-6) -> Tuple[float, np.ndarray]:
    """
    Solve the tangency geometry for a spherically-blunted cone nose.

    A conical generatrix runs from the axis (apex) to (length, radius).
    A spherical cap of radius ``r_n = bluntness * radius`` is blended in
    tangentially near the apex. The cone half-angle and tangent-point
    location are refined iteratively (fixed-point / Newton-style update)
    until the change between iterations is below ``tol``.

    Parameters
    ----------
    length    : axial nose length (mm), > 0
    radius    : base radius of the nose (mm), > 0
    bluntness : fraction of the base radius used as the spherical cap
                radius, in [0, 1). 0 => perfectly sharp cone.
    tol       : convergence tolerance for the iterative solve

    Returns
    -------
    (x_t, params) where:
        x_t    : axial distance (mm) from the apex to the tangent point
        params : np.ndarray([x_cap_centre, r_n, half_angle_rad])
    """
    length = _validate_positive(length, 'length')
    radius = _validate_positive(radius, 'radius')
    if not (0.0 <= bluntness < 1.0):
        raise ValueError("'bluntness' must be in the range [0, 1)")

    if bluntness < tol:
        theta = math.atan2(radius, length)
        return 0.0, np.array([0.0, 0.0, theta])

    r_n = bluntness * radius
    theta = math.atan2(radius, length)      # initial half-angle estimate
    x_t = r_n * math.sin(theta)

    for _ in range(200):
        r_t = x_t * math.tan(theta)
        theta_new = math.atan2(max(radius - r_t, 1e-9), max(length - x_t, 1e-9))
        x_t_new = r_n * math.sin(theta_new)
        if abs(x_t_new - x_t) < tol and abs(theta_new - theta) < tol:
            x_t, theta = x_t_new, theta_new
            break
        x_t, theta = x_t_new, theta_new

    x_c = x_t - r_n * math.sin(theta)  # axial location of the cap centre
    return float(x_t), np.array([x_c, r_n, theta])


# =========================================================
# NOSE GENERATION (surface of revolution)
# =========================================================
def generate_nose(nose_length: float, nose_diameter: float,
                   nose_bluntness: float
                   ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Generate a revolved 3-D surface mesh for a spherically-blunted conical
    nose, apex at x=0, base at x=nose_length with radius = nose_diameter/2.

    Returns (X, Y, Z) as (N_AXIAL, N_THETA) meshgrid arrays.
    """
    nose_length = _validate_positive(nose_length, 'nose_length')
    nose_diameter = _validate_positive(nose_diameter, 'nose_diameter')
    radius = nose_diameter / 2.0

    x_t, params = solve_unblunted_cone(nose_length, radius, nose_bluntness)
    x_c, r_n, theta = params

    x = np.linspace(0.0, nose_length, _N_AXIAL)
    r = np.empty_like(x)

    if nose_bluntness < 1e-6:
        r = x * math.tan(theta)
    else:
        for i, xi in enumerate(x):
            if xi <= x_t:
                # spherical cap region
                dx = xi - x_c
                r[i] = math.sqrt(max(r_n ** 2 - dx ** 2, 0.0))
            else:
                # straight conical region
                r[i] = (xi - x_t) * math.tan(theta) + x_t * math.tan(theta)
    r = np.clip(r, 0.0, radius)
    r[-1] = radius  # force exact match at the base

    th = np.linspace(0.0, 2.0 * math.pi, _N_THETA)
    X, TH = np.meshgrid(x, th, indexing='ij')
    R = np.tile(r.reshape(-1, 1), (1, _N_THETA))
    Y = R * np.cos(TH)
    Z = R * np.sin(TH)
    return X, Y, Z


# =========================================================
# CYLINDRICAL FUSELAGE
# =========================================================
def generate_body(body_length: float, body_diameter: float,
                   nose_length: float
                   ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Generate a revolved cylindrical fuselage mesh, starting at
    x=nose_length (i.e. immediately aft of the nose base) and running
    for body_length. Returns (X, Y, Z) as (N_AXIAL, N_THETA) arrays.
    """
    body_length = _validate_positive(body_length, 'body_length')
    body_diameter = _validate_positive(body_diameter, 'body_diameter')
    nose_length = _validate_positive(nose_length, 'nose_length')
    radius = body_diameter / 2.0

    x = np.linspace(nose_length, nose_length + body_length, _N_AXIAL)
    th = np.linspace(0.0, 2.0 * math.pi, _N_THETA)
    X, TH = np.meshgrid(x, th, indexing='ij')
    Y = radius * np.cos(TH)
    Z = radius * np.sin(TH)
    return X, Y, Z


# =========================================================
# BICONVEX THICKNESS DISTRIBUTION
# =========================================================
def _biconvex_thickness(x: np.ndarray, root_chord: float, tip_chord: float,
                         root_th: float, tip_th: float) -> np.ndarray:
    """
    Linear spanwise taper of the panel's maximum thickness.

    ``x`` is a normalised spanwise coordinate array in [0, 1] (0 = root,
    1 = tip). Returns the max half-thickness (biconvex crown) at each
    spanwise station, interpolated between root_th and tip_th. Used by
    generate_fin_panel() together with a symmetric parabolic-arc
    (biconvex) chordwise profile.
    """
    x = np.asarray(x, dtype=float)
    return root_th + (tip_th - root_th) * x


# =========================================================
# FIN / WING PANEL GENERATION
# =========================================================
def generate_fin_panel(le: float, root_chord: float, tip_chord: float,
                        semi_span: float, hinge_line: float,
                        root_th: float, tip_th: float, sweep: float,
                        body_diameter: float, side: str = "right"
                        ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Generate one biconvex fin/wing panel as a 3-D surface mesh.

    Parameters
    ----------
    le            : axial position (mm) of the root leading edge
    root_chord    : chord length at the body-side root (mm)
    tip_chord     : chord length at the panel tip (mm)
    semi_span     : span of the panel measured from the body surface (mm)
    hinge_line    : axial reference used for the sweep pivot (mm) — for
                    an unswept root leading edge this normally equals ``le``
    root_th       : maximum thickness at the root (mm)
    tip_th        : maximum thickness at the tip (mm)
    sweep         : leading-edge sweep angle (deg)
    body_diameter : fuselage diameter at the panel root (mm)
    side          : 'right', 'left', 'top', or 'bottom' — which side of
                    the body the panel is attached to (cruciform layout)

    Returns (X, Y, Z) as (N_SPAN, 2*N_CHORD) meshgrid arrays.
    """
    root_chord = _validate_positive(root_chord, 'root_chord')
    tip_chord = _validate_positive(tip_chord, 'tip_chord')
    semi_span = _validate_positive(semi_span, 'semi_span')
    body_diameter = _validate_positive(body_diameter, 'body_diameter')
    sweep_rad = _deg2rad(sweep)

    r_body = body_diameter / 2.0
    eta = np.linspace(0.0, 1.0, _N_SPAN)               # 0=root, 1=tip
    span_pos = r_body + eta * semi_span                # radial station (mm)
    chord = root_chord + (tip_chord - root_chord) * eta
    le_x = hinge_line + eta * semi_span * math.tan(sweep_rad)
    max_th = _biconvex_thickness(eta, root_chord, tip_chord, root_th, tip_th)

    xi = np.linspace(0.0, 1.0, _N_CHORD)                # chordwise station
    # symmetric parabolic-arc (biconvex) profile, +/- surfaces
    prof_upper = 4.0 * xi * (1.0 - xi)                  # 0..1, peak at mid-chord
    prof_full = np.concatenate([prof_upper, -prof_upper[::-1]])
    xi_full = np.concatenate([xi, xi[::-1]])

    X = np.empty((_N_SPAN, 2 * _N_CHORD))
    R = np.empty((_N_SPAN, 2 * _N_CHORD))   # radial (in-plane) coordinate

    for i in range(_N_SPAN):
        X[i, :] = le_x[i] + xi_full * chord[i]
        R[i, :] = span_pos[i] + prof_full * (max_th[i] / 2.0)

    side = side.lower()
    if side == 'right':
        Y, Z = R, np.zeros_like(R)
    elif side == 'left':
        Y, Z = -R, np.zeros_like(R)
    elif side == 'top':
        Y, Z = np.zeros_like(R), R
    elif side == 'bottom':
        Y, Z = np.zeros_like(R), -R
    else:
        raise ValueError("side must be one of 'right', 'left', 'top', 'bottom'")

    return X, Y, Z


# =========================================================
# MATPLOTLIB STATIC RENDER
# =========================================================
def plot_matplotlib(nose: Tuple[np.ndarray, np.ndarray, np.ndarray],
                     body: Tuple[np.ndarray, np.ndarray, np.ndarray],
                     fins: List[Tuple[np.ndarray, np.ndarray, np.ndarray]],
                     png_out: str, show: bool = False,
                     block: bool = True) -> None:
    """
    Render the nose + body + fin panels as a shaded 3-D matplotlib
    surface plot and save it to ``png_out``.
    """
    fig = plt.figure(figsize=(11, 6))
    ax = fig.add_subplot(111, projection='3d')

    Xn, Yn, Zn = nose
    Xb, Yb, Zb = body
    ax.plot_surface(Xn, Yn, Zn, color='#3B82F6', alpha=0.85,
                     linewidth=0, antialiased=True)
    ax.plot_surface(Xb, Yb, Zb, color='#06B6D4', alpha=0.85,
                     linewidth=0, antialiased=True)

    for Xf, Yf, Zf in fins:
        ax.plot_surface(Xf, Yf, Zf, color='#F59E0B', alpha=0.95,
                         linewidth=0, antialiased=True)

    all_x = np.concatenate([Xn.ravel(), Xb.ravel()] +
                            [f[0].ravel() for f in fins])
    span = max(all_x.max() - all_x.min(), 1.0)
    ax.set_box_aspect((span, span * 0.4, span * 0.4))
    ax.set_xlabel('X — length (mm)')
    ax.set_ylabel('Y (mm)')
    ax.set_zlabel('Z (mm)')
    ax.set_title('Aerodynamic Body — 3-D Geometry')
    ax.view_init(elev=18, azim=-60)

    fig.tight_layout()
    fig.savefig(png_out, dpi=150, bbox_inches='tight')
    if show:
        plt.show(block=block)
    else:
        plt.close(fig)


# =========================================================
# PLOTLY MESH HELPER
# =========================================================
def _make_plotly_mesh(X, Y, Z, name):
    """
    Convert a structured (rows, cols) surface grid into a triangulated
    plotly.graph_objects.Mesh3d trace.
    """
    if not _HAS_PLOTLY:
        raise RuntimeError('plotly is not installed')

    rows, cols = X.shape
    xs, ys, zs = X.ravel(), Y.ravel(), Z.ravel()

    tri_i, tri_j, tri_k = [], [], []
    for r in range(rows - 1):
        for c in range(cols - 1):
            a = r * cols + c
            b = r * cols + (c + 1)
            cidx = (r + 1) * cols + c
            d = (r + 1) * cols + (c + 1)
            tri_i += [a, b]
            tri_j += [b, d]
            tri_k += [cidx, cidx]

    return go.Mesh3d(x=xs, y=ys, z=zs, i=tri_i, j=tri_j, k=tri_k,
                      name=name, opacity=1.0, flatshading=True,
                      showscale=False)


# =========================================================
# PLOTLY INTERACTIVE DASHBOARD
# =========================================================
def plot_plotly(nose: Tuple[np.ndarray, np.ndarray, np.ndarray],
                 body: Tuple[np.ndarray, np.ndarray, np.ndarray],
                 fins: List[Tuple[np.ndarray, np.ndarray, np.ndarray]],
                 html_out: str, stats: Dict[str, Any]) -> None:
    """
    Build an interactive 3-D model (Mesh3d traces) with a sidebar
    statistics table and save it as a standalone HTML file.
    Silently no-ops if plotly is not installed.
    """
    if not _HAS_PLOTLY:
        print('[aero_body] plotly not installed — skipping interactive HTML.')
        return

    fig = make_subplots(
        rows=1, cols=2, column_widths=[0.72, 0.28],
        specs=[[{'type': 'scene'}, {'type': 'table'}]],
        subplot_titles=('3-D Model', 'Summary Statistics'))

    fig.add_trace(_make_plotly_mesh(*nose, 'Nose'), row=1, col=1)
    fig.add_trace(_make_plotly_mesh(*body, 'Body'), row=1, col=1)
    for idx, fin in enumerate(fins):
        fig.add_trace(_make_plotly_mesh(*fin, f'Fin_{idx+1}'), row=1, col=1)

    keys = list(stats.keys())
    vals = [f'{stats[k]:.4g}' if isinstance(stats[k], (int, float))
            else str(stats[k]) for k in keys]
    fig.add_trace(go.Table(
        header=dict(values=['Statistic', 'Value'],
                    fill_color='#111827', font=dict(color='white', size=12)),
        cells=dict(values=[keys, vals],
                   fill_color='#1C2333', font=dict(color='#F1F5F9', size=11))
    ), row=1, col=2)

    fig.update_scenes(aspectmode='data')
    fig.update_layout(
        title='DRDL Aerospace AI Platform — Interactive 3-D Geometry',
        paper_bgcolor='#0B0F1A', font=dict(color='#F1F5F9'),
        showlegend=False, margin=dict(l=10, r=10, t=60, b=10))

    fig.write_html(html_out, include_plotlyjs='cdn')


# =========================================================
# INTERACTIVE PROMPT
# =========================================================
def prompt_parameter(name: str, default: Any, typ: type = float) -> Any:
    """Prompt the user for a parameter value, showing the default."""
    raw = input(f'{name} [{default}]: ').strip()
    if raw == '':
        return default
    try:
        return typ(raw)
    except (TypeError, ValueError):
        print(f'  Invalid value, keeping default {default}.')
        return default


# =========================================================
# DERIVED STATISTICS
# =========================================================
def _fuselage_stats(nose_length: float, body_length: float,
                     body_diameter: float) -> Dict[str, float]:
    """Compute fuselage length, volume, fineness ratio, wetted area (approx)."""
    nose_length = _validate_positive(nose_length, 'nose_length')
    body_length = _validate_positive(body_length, 'body_length')
    body_diameter = _validate_positive(body_diameter, 'body_diameter')
    radius = body_diameter / 2.0

    total_length = nose_length + body_length
    nose_volume = (1.0 / 3.0) * math.pi * radius ** 2 * nose_length  # cone approx
    body_volume = math.pi * radius ** 2 * body_length
    total_volume = nose_volume + body_volume
    fineness_ratio = total_length / body_diameter
    wetted_area = (math.pi * radius * math.sqrt(radius ** 2 + nose_length ** 2)
                   + 2.0 * math.pi * radius * body_length)

    return {
        'total_length_mm': round(total_length, 2),
        'total_volume_mm3': round(total_volume, 2),
        'fineness_ratio': round(fineness_ratio, 3),
        'wetted_area_mm2': round(wetted_area, 2),
    }


def _fin_stats(root_chord: float, tip_chord: float, semi_span: float,
               root_th: float, tip_th: float) -> Dict[str, float]:
    """Compute one-panel area, full-span aspect ratio, taper ratio, mean t/c."""
    root_chord = _validate_positive(root_chord, 'root_chord')
    tip_chord = _validate_positive(tip_chord, 'tip_chord')
    semi_span = _validate_positive(semi_span, 'semi_span')

    panel_area = 0.5 * (root_chord + tip_chord) * semi_span
    full_span = 2.0 * semi_span
    aspect_ratio = full_span ** 2 / (2.0 * panel_area)
    taper_ratio = tip_chord / root_chord
    mean_tc = 0.5 * (root_th / root_chord + tip_th / tip_chord)

    return {
        'panel_area_mm2': round(panel_area, 2),
        'aspect_ratio': round(aspect_ratio, 3),
        'taper_ratio': round(taper_ratio, 3),
        'mean_thickness_ratio': round(mean_tc, 4),
    }


# =========================================================
# TOP-LEVEL BUILD + VISUALISE
# =========================================================
def visualize_aero_body(params: Dict[str, Any]) -> None:
    """
    Build the full geometry from ``params`` and render both the static
    PNG (matplotlib) and, if available, the interactive HTML (plotly).

    Required keys in ``params``: nose_len, nose_diameter, nose_bluntness,
    body_len, body_diameter, wing_le, root_chord, tip_chord, semi_span,
    root_th, tip_th, wing_sweep, tail_le, root_chord1, tip_chord1,
    semi_span1, root_th1, tip_th1, png_out, html_out, layout.
    """
    layout = params.get('layout', 'cruciform')
    sides_wing = ('right', 'left', 'top', 'bottom') if layout == 'cruciform' \
        else ('right', 'left')
    sides_tail = sides_wing

    nose = generate_nose(params['nose_len'], params['nose_diameter'],
                          params['nose_bluntness'])
    body = generate_body(params['body_len'], params['body_diameter'],
                          params['nose_len'])

    fins = []
    for s in sides_wing:
        fins.append(generate_fin_panel(
            params['wing_le'], params['root_chord'], params['tip_chord'],
            params['semi_span'], params['wing_le'], params['root_th'],
            params['tip_th'], params['wing_sweep'], params['body_diameter'],
            side=s))
    for s in sides_tail:
        fins.append(generate_fin_panel(
            params['tail_le'], params['root_chord1'], params['tip_chord1'],
            params['semi_span1'], params['tail_le'], params['root_th1'],
            params['tip_th1'], 0.0, params['body_diameter'], side=s))

    stats = {}
    stats.update(_fuselage_stats(params['nose_len'], params['body_len'],
                                  params['body_diameter']))
    stats.update({f'wing_{k}': v for k, v in _fin_stats(
        params['root_chord'], params['tip_chord'], params['semi_span'],
        params['root_th'], params['tip_th']).items()})
    stats.update({f'tail_{k}': v for k, v in _fin_stats(
        params['root_chord1'], params['tip_chord1'], params['semi_span1'],
        params['root_th1'], params['tip_th1']).items()})

    png_out = params.get('png_out', 'aero_body.png')
    html_out = params.get('html_out', 'aero_body.html')

    plot_matplotlib(nose, body, fins, png_out, show=False)
    plot_plotly(nose, body, fins, html_out, stats)

    print(f'[aero_body] Saved PNG  -> {png_out}')
    if _HAS_PLOTLY:
        print(f'[aero_body] Saved HTML -> {html_out}')


# =========================================================
# CLI
# =========================================================
def _build_arg_parser() -> argparse.ArgumentParser:
    """Build the command-line argument parser (defaults match app.py)."""
    p = argparse.ArgumentParser(
        description='Generate a 3-D aerodynamic body (nose + fuselage + '
                    'fins) and render it as PNG / interactive HTML.')
    p.add_argument('--nose_len', type=float, default=300.0)
    p.add_argument('--nose_diameter', type=float, default=None,
                    help='defaults to body_diameter if omitted')
    p.add_argument('--nose_bluntness', type=float, default=0.08)
    p.add_argument('--body_len', type=float, default=2700.0)
    p.add_argument('--body_diameter', type=float, default=300.0)
    p.add_argument('--wing_le', type=float, default=1500.0)
    p.add_argument('--root_chord', type=float, default=200.0)
    p.add_argument('--tip_chord', type=float, default=150.0)
    p.add_argument('--semi_span', type=float, default=1000.0)
    p.add_argument('--root_th', type=float, default=20.0)
    p.add_argument('--tip_th', type=float, default=5.0)
    p.add_argument('--wing_sweep', type=float, default=2.86)
    p.add_argument('--tail_le', type=float, default=2870.0)
    p.add_argument('--root_chord1', type=float, default=120.0)
    p.add_argument('--tip_chord1', type=float, default=60.0)
    p.add_argument('--semi_span1', type=float, default=100.0)
    p.add_argument('--root_th1', type=float, default=15.0)
    p.add_argument('--tip_th1', type=float, default=5.0)
    p.add_argument('--layout', choices=['cruciform', 'conventional'],
                    default='cruciform')
    p.add_argument('--png_out', type=str, default='aero_body.png')
    p.add_argument('--html_out', type=str, default='aero_body.html')
    p.add_argument('-i', '--interactive', action='store_true',
                    help='prompt for each parameter interactively')
    return p


def main() -> None:
    """Entry point: parse CLI args (or prompt interactively) and render."""
    parser = _build_arg_parser()
    args = parser.parse_args()
    params = vars(args)

    if args.interactive:
        for key, default in list(params.items()):
            if key in ('interactive',):
                continue
            typ = str if key in ('layout', 'png_out', 'html_out') else float
            params[key] = prompt_parameter(key, default, typ)

    if params.get('nose_diameter') in (None, 0):
        params['nose_diameter'] = params['body_diameter']

    visualize_aero_body(params)


if __name__ == '__main__':
    main()
