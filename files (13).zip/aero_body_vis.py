#!/usr/bin/env python3
"""
Aerodynamic Body 3D Visualization Tool
Generates and plots a 3D aerodynamic body (nose cone, fuselage, wing, and tail fins)
based on geometric parameters.
"""

import os
import argparse
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from matplotlib.colors import LightSource, to_rgb

# Try to import plotly for interactive HTML generation
try:
    import plotly.graph_objects as go
    import plotly.offline as pyo
    PLOTLY_AVAILABLE = True
except ImportError:
    PLOTLY_AVAILABLE = False


def solve_unblunted_cone(L_n, R, r_b):
    """
    Solves for the unblunted cone length given actual nose length, base radius,
    and tip bluntness radius using a simple binary search.
    """
    if r_b >= R or r_b <= 0:
        return None
    
    # Solve: L_un - r_b * (sqrt(R^2 + L_un^2)/R - 1) - L_n = 0
    low = L_n
    high = L_n + r_b * (R + L_n) / R
    for _ in range(100):
        mid = 0.5 * (low + high)
        sin_theta = R / np.sqrt(R**2 + mid**2)
        f_val = mid - r_b * (1.0 / sin_theta - 1.0) - L_n
        if abs(f_val) < 1e-7:
            return mid
        if f_val < 0:
            low = mid
        else:
            high = mid
    return (low + high) / 2.0


def generate_nose(L_n, D_n, bluntness, n_x=50, n_theta=50):
    """
    Generates 3D coordinates for the nose section.
    Aligns along the X-axis starting at X=0 to X=L_n.
    """
    # Safeguard bluntness input
    if bluntness > 1.0:
        bluntness = bluntness / 100.0
    bluntness = np.clip(bluntness, 0.0, 1.0)
    
    R = D_n / 2.0
    r_b = bluntness * R
    
    x_coords = np.linspace(0, L_n, n_x)
    theta = np.linspace(0, 2 * np.pi, n_theta)
    theta_grid, x_grid = np.meshgrid(theta, x_coords)
    
    r_profile = np.zeros_like(x_coords)
    
    # Try to solve for spherically blunted cone
    # For spherically blunted cone, the sphere tip radius must be strictly less than the base radius
    L_un = solve_unblunted_cone(L_n, R, r_b) if (0 < r_b < R) else None
    
    if L_un is not None and r_b > 0 and r_b < R:
        # Spherically blunted cone geometry
        theta_cone = np.arctan(R / L_un)
        sin_t = np.sin(theta_cone)
        cos_t = np.cos(theta_cone)
        
        x_c = r_b / sin_t  # Sphere center relative to unblunted tip
        x_start = x_c - r_b
        x_t = x_c - r_b * sin_t  # Tangent point
        
        for i, x_act in enumerate(x_coords):
            x = x_act + x_start
            if x < x_t:
                # Spherical cap (with clipping to prevent negative values in sqrt)
                r_profile[i] = np.sqrt(np.clip(r_b**2 - (x - x_c)**2, 0.0, None))
            else:
                # Conical surface
                r_profile[i] = R * (x / L_un)
    else:
        # Fallback to power-law nose (parabolic profiles for bluntness, cone for sharp)
        # bluntness = 0 -> cone (n=1)
        # bluntness = 1 -> ellipsoid/hemisphere (n=0.5)
        n_power = 1.0 - 0.5 * bluntness
        # Handle case where L_n is zero to avoid division by zero
        L_n_safe = max(L_n, 1e-9)
        r_profile = R * (x_coords / L_n_safe) ** n_power

    # Build 3D mesh
    r_grid = np.tile(r_profile[:, np.newaxis], (1, n_theta))
    X = x_grid
    Y = r_grid * np.cos(theta_grid)
    Z = r_grid * np.sin(theta_grid)
    
    return X, Y, Z


def generate_body(L_b, D_b, start_x, n_x=50, n_theta=50):
    """
    Generates 3D coordinates for the cylindrical body section.
    Aligns along the X-axis from start_x to start_x + L_b.
    """
    R = D_b / 2.0
    x_coords = np.linspace(start_x, start_x + L_b, n_x)
    theta = np.linspace(0, 2 * np.pi, n_theta)
    
    theta_grid, x_grid = np.meshgrid(theta, x_coords)
    r_grid = np.full_like(x_grid, R)
    
    X = x_grid
    Y = r_grid * np.cos(theta_grid)
    Z = r_grid * np.sin(theta_grid)
    
    return X, Y, Z


def generate_fin_panel(le_x, root_chord, tip_chord, semi_span, sweep_deg,
                       root_th, tip_th, phi_deg, hinge_line_frac=None,
                       n_span=30, n_chord=20):
    """
    Generates 3D coordinates for a single wing or fin panel rotated around the X-axis.
    phi_deg: Rotation angle around X-axis (0 = right wing, 90 = top fin, etc.)
    """
    eta = np.linspace(0, 1, n_span)
    s = np.linspace(0, 1, n_chord)
    
    s_grid, eta_grid = np.meshgrid(s, eta)
    
    # Local span coordinate
    y_local = eta_grid * semi_span
    
    # Chord and thickness at each span station
    chord_grid = root_chord + (tip_chord - root_chord) * eta_grid
    thickness_grid = root_th + (tip_th - root_th) * eta_grid
    
    # Leading edge X coordinate at each span station
    le_x_grid = le_x + y_local * np.tan(np.radians(sweep_deg))
    
    # X coordinate of the grid points
    X = le_x_grid + s_grid * chord_grid
    
    # Local Z (thickness) using a biconvex airfoil shape
    # Z_local ranges from -t/2 to +t/2
    Z_local_upper = 0.5 * thickness_grid * 4 * s_grid * (1 - s_grid)
    Z_local_lower = -Z_local_upper
    
    # Rotate around X-axis by phi_deg
    phi_rad = np.radians(phi_deg)
    cos_phi = np.cos(phi_rad)
    sin_phi = np.sin(phi_rad)
    
    # Upper surface 3D coordinates
    Y_upper = y_local * cos_phi - Z_local_upper * sin_phi
    Z_upper = y_local * sin_phi + Z_local_upper * cos_phi
    
    # Lower surface 3D coordinates
    Y_lower = y_local * cos_phi - Z_local_lower * sin_phi
    Z_lower = y_local * sin_phi + Z_local_lower * cos_phi
    
    # Compute hinge line coordinates if requested
    hinge_line_pts = None
    if hinge_line_frac is not None:
        y_h_local = eta * semi_span
        c_h = root_chord + (tip_chord - root_chord) * eta
        x_le_h = le_x + y_h_local * np.tan(np.radians(sweep_deg))
        
        x_hl = x_le_h + hinge_line_frac * c_h
        t_h = root_th + (tip_th - root_th) * eta
        z_h_upper = 0.5 * t_h * 4 * hinge_line_frac * (1 - hinge_line_frac)
        z_h_lower = -z_h_upper
        
        # Upper hinge line
        y_hl_u = y_h_local * cos_phi - z_h_upper * sin_phi
        z_hl_u = y_h_local * sin_phi + z_h_upper * cos_phi
        
        # Lower hinge line
        y_hl_l = y_h_local * cos_phi - z_h_lower * sin_phi
        z_hl_l = y_h_local * sin_phi + z_h_lower * cos_phi
        
        hinge_line_pts = {
            'upper': (x_hl, y_hl_u, z_hl_u),
            'lower': (x_hl, y_hl_l, z_hl_l)
        }
        
    return X, Y_upper, Z_upper, X, Y_lower, Z_lower, hinge_line_pts


_fig = None
_ax = None


def plot_matplotlib(geometry, hinge_lines, output_file, show=False, block=False):
    """
    Plots the aerodynamic body in 3D using Matplotlib and saves to PNG.
    If the figure is already open, updates it in-place.
    """
    global _fig, _ax
    
    if _fig is not None and plt.fignum_exists(_fig.number):
        _ax.clear()
    else:
        plt.ion()  # Turn on interactive mode
        _fig = plt.figure(figsize=(12, 10))
        _ax = _fig.add_subplot(111, projection='3d')
        
    ax = _ax
    
    # Plot nose
    X, Y, Z = geometry['nose']
    ax.plot_surface(X, Y, Z, color='lightgray', edgecolor='none', alpha=0.9, shade=True)
    
    # Plot body
    X, Y, Z = geometry['body']
    ax.plot_surface(X, Y, Z, color='gray', edgecolor='none', alpha=0.9, shade=True)
    
    # Plot wings and tail fins
    for part_name, surfaces in geometry['wings_tails'].items():
        # Choose colors based on wings vs tails
        color = 'royalblue' if 'wing' in part_name else 'crimson'
        for surface in surfaces:
            X, Y, Z = surface
            ax.plot_surface(X, Y, Z, color=color, edgecolor='none', alpha=0.85, shade=True)
            
    # Plot hinge lines
    for part_name, hl_data in hinge_lines.items():
        if hl_data:
            # Upper hinge line
            xu, yu, zu = hl_data['upper']
            ax.plot(xu, yu, zu, color='yellow', linestyle='--', linewidth=2, label=f'{part_name} Hinge Line' if 'right' in part_name or 'top' in part_name else "")
            # Lower hinge line
            xl, yl, zl = hl_data['lower']
            ax.plot(xl, yl, zl, color='yellow', linestyle='--', linewidth=2)

    # Set labels and aspect ratio
    ax.set_xlabel('X (Length)')
    ax.set_ylabel('Y (Span)')
    ax.set_zlabel('Z (Height)')
    ax.set_title('Aerodynamic Body 3D Visualization')
    
    # Equal aspect ratio trick
    X_all = np.concatenate([geometry['nose'][0].flatten(), geometry['body'][0].flatten()])
    Y_all = np.concatenate([geometry['nose'][1].flatten(), geometry['body'][1].flatten()])
    Z_all = np.concatenate([geometry['nose'][2].flatten(), geometry['body'][2].flatten()])
    
    max_range = np.array([X_all.max()-X_all.min(), Y_all.max()-Y_all.min(), Z_all.max()-Z_all.min()]).max() / 2.0
    mid_x = (X_all.max()+X_all.min()) * 0.5
    mid_y = (Y_all.max()+Y_all.min()) * 0.5
    mid_z = (Z_all.max()+Z_all.min()) * 0.5
    ax.set_xlim(mid_x - max_range, mid_x + max_range)
    ax.set_ylim(mid_y - max_range, mid_y + max_range)
    ax.set_zlim(mid_z - max_range, mid_z + max_range)
    
    # Dark theme or clean grid
    ax.grid(True)
    ax.legend()
    
    # Save file
    _fig.savefig(output_file, dpi=150, bbox_inches='tight')
    print(f"Matplotlib static plot saved to: {output_file}")
    
    if show:
        _fig.canvas.draw_idle()
        plt.pause(0.01)
        if block:
            plt.ioff()
            plt.show(block=True)


def plot_plotly(geometry, hinge_lines, params, output_file):
    """
    Plots the aerodynamic body in 3D using Plotly and saves to an interactive HTML dashboard.
    """
    if not PLOTLY_AVAILABLE:
        print("Plotly is not available. Skipping interactive HTML plot.")
        return
        
    fig = go.Figure()
    
    # Nose Surface
    X, Y, Z = geometry['nose']
    fig.add_trace(go.Surface(
        x=X, y=Y, z=Z,
        colorscale=[[0, 'rgb(220,220,220)'], [1, 'rgb(180,180,180)']],
        showscale=False,
        name='Nose Cone',
        lighting=dict(ambient=0.6, diffuse=0.8, roughness=0.2, specular=0.5)
    ))
    
    # Body Surface
    X, Y, Z = geometry['body']
    fig.add_trace(go.Surface(
        x=X, y=Y, z=Z,
        colorscale=[[0, 'rgb(120,120,120)'], [1, 'rgb(100,100,100)']],
        showscale=False,
        name='Fuselage',
        lighting=dict(ambient=0.6, diffuse=0.8, roughness=0.2, specular=0.5)
    ))
    
    # Wings and Fins
    for part_name, surfaces in geometry['wings_tails'].items():
        is_wing = 'wing' in part_name
        color = 'royalblue' if is_wing else 'crimson'
        
        # Plotly surfaces
        for idx, surface in enumerate(surfaces):
            X, Y, Z = surface
            surf_name = f"{part_name.capitalize()} {'Upper' if idx==0 else 'Lower'}"
            fig.add_trace(go.Surface(
                x=X, y=Y, z=Z,
                colorscale=[[0, color], [1, color]],
                showscale=False,
                name=surf_name,
                lighting=dict(ambient=0.5, diffuse=0.8, roughness=0.3, specular=0.5)
            ))
            
    # Hinge lines
    for part_name, hl_data in hinge_lines.items():
        if hl_data:
            xu, yu, zu = hl_data['upper']
            xl, yl, zl = hl_data['lower']
            
            fig.add_trace(go.Scatter3d(
                x=xu, y=yu, z=zu,
                mode='lines',
                line=dict(color='yellow', width=5, dash='dash'),
                name=f'{part_name.capitalize()} Hinge (Upper)'
            ))
            fig.add_trace(go.Scatter3d(
                x=xl, y=yl, z=zl,
                mode='lines',
                line=dict(color='yellow', width=5, dash='dash'),
                name=f'{part_name.capitalize()} Hinge (Lower)',
                showlegend=False
            ))

    # Layout styling (Dark mode, premium feel)
    fig.update_layout(
        template='plotly_dark',
        scene=dict(
            xaxis=dict(title='X (Length)', backgroundcolor='rgb(20,20,20)', gridcolor='gray', showbackground=True),
            yaxis=dict(title='Y (Span)', backgroundcolor='rgb(20,20,20)', gridcolor='gray', showbackground=True),
            zaxis=dict(title='Z (Height)', backgroundcolor='rgb(20,20,20)', gridcolor='gray', showbackground=True),
            aspectmode='data'
        ),
        margin=dict(l=0, r=0, b=0, t=0),
    )
    
    # Calculate geometric quantities
    L_total = params["nose_length"] + params["body_length"]
    R_b = params["body_diameter"] / 2.0
    V_body = np.pi * (R_b**2) * params["body_length"]
    
    # Blunted cone or power-law volume approximation
    V_nose = np.pi * (R_b**2) * params["nose_length"] * (1.0/3.0 + 0.167 * params["nose_bluntness"])
    V_total = V_body + V_nose
    
    # Wing calculations
    S_wing_one = params["semi_span"] * (params["root_chord"] + params["tip_chord"]) / 2.0
    S_wing = 2.0 * S_wing_one
    AR_wing = (2.0 * params["semi_span"])**2 / S_wing if S_wing > 0 else 0.0
    taper_wing = params["tip_chord"] / params["root_chord"] if params["root_chord"] > 0 else 0.0
    
    # Tail calculations
    num_fins = 4 if params["tail_config"] == 'cruciform' else 3
    S_tail_one = params["tail_semi_span"] * (params["tail_root_chord"] + params["tail_tip_chord"]) / 2.0
    S_tail_total = num_fins * S_tail_one
    AR_tail = (2.0 * params["tail_semi_span"])**2 / (2.0 * S_tail_one) if S_tail_one > 0 else 0.0
    taper_tail = params["tail_tip_chord"] / params["tail_root_chord"] if params["tail_root_chord"] > 0 else 0.0

    # Convert Plotly figure to JSON
    import json
    import plotly.utils
    fig_json = json.dumps(fig, cls=plotly.utils.PlotlyJSONEncoder)

    html_content = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Aerodynamic Design Dashboard</title>
    <script src="https://cdn.plot.ly/plotly-2.24.1.min.js"></script>
    <style>
        body {{
            margin: 0;
            padding: 0;
            background-color: #0b0f19;
            color: #f3f4f6;
            font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
            display: flex;
            height: 100vh;
            overflow: hidden;
        }}
        #sidebar {{
            width: 380px;
            background-color: #111827;
            border-right: 1px solid #1f2937;
            display: flex;
            flex-direction: column;
            padding: 20px;
            overflow-y: auto;
            box-sizing: border-box;
        }}
        #viewer {{
            flex-grow: 1;
            height: 100%;
        }}
        h1 {{
            font-size: 1.15rem;
            font-weight: 700;
            margin-bottom: 20px;
            color: #3b82f6;
            text-transform: uppercase;
            letter-spacing: 1px;
            border-bottom: 2px solid #1f2937;
            padding-bottom: 10px;
            margin-top: 0;
        }}
        .card {{
            background-color: #1f2937;
            border: 1px solid #374151;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 15px;
        }}
        .card-title {{
            font-size: 0.85rem;
            font-weight: 600;
            color: #60a5fa;
            text-transform: uppercase;
            border-bottom: 1px solid #374151;
            padding-bottom: 5px;
            margin-bottom: 10px;
            letter-spacing: 0.5px;
        }}
        .stat-row {{
            display: flex;
            justify-content: space-between;
            font-size: 0.85rem;
            margin-bottom: 6px;
        }}
        .stat-label {{
            color: #9ca3af;
        }}
        .stat-value {{
            font-weight: 600;
            color: #ffffff;
        }}
    </style>
</head>
<body>
    <div id="sidebar">
        <h1>Aerodynamic Details</h1>
        
        <div class="card">
            <div class="card-title">Fuselage Specs</div>
            <div class="stat-row">
                <span class="stat-label">Total Length</span>
                <span class="stat-value">{L_total:.2f} units</span>
            </div>
            <div class="stat-row">
                <span class="stat-label">Body Length</span>
                <span class="stat-value">{params['body_length']:.2f} units</span>
            </div>
            <div class="stat-row">
                <span class="stat-label">Nose Length</span>
                <span class="stat-value">{params['nose_length']:.2f} units</span>
            </div>
            <div class="stat-row">
                <span class="stat-label">Body Diameter</span>
                <span class="stat-value">{params['body_diameter']:.2f} units</span>
            </div>
            <div class="stat-row">
                <span class="stat-label">Nose Bluntness</span>
                <span class="stat-value">{params['nose_bluntness']*100:.1f}%</span>
            </div>
            <div class="stat-row">
                <span class="stat-label">Fuselage Volume</span>
                <span class="stat-value">{V_body:.2f} units³</span>
            </div>
            <div class="stat-row">
                <span class="stat-label">Nose Volume</span>
                <span class="stat-value">{V_nose:.2f} units³</span>
            </div>
            <div class="stat-row">
                <span class="stat-label">Total Volume</span>
                <span class="stat-value">{V_total:.2f} units³</span>
            </div>
        </div>

        <div class="card">
            <div class="card-title">Wing Geometry</div>
            <div class="stat-row">
                <span class="stat-label">Total Area (both)</span>
                <span class="stat-value">{S_wing:.2f} units²</span>
            </div>
            <div class="stat-row">
                <span class="stat-label">Semi-span</span>
                <span class="stat-value">{params['semi_span']:.2f} units</span>
            </div>
            <div class="stat-row">
                <span class="stat-label">Aspect Ratio</span>
                <span class="stat-value">{AR_wing:.2f}</span>
            </div>
            <div class="stat-row">
                <span class="stat-label">Taper Ratio</span>
                <span class="stat-value">{taper_wing:.3f}</span>
            </div>
            <div class="stat-row">
                <span class="stat-label">Sweep Angle</span>
                <span class="stat-value">{params['wing_sweep']:.2f}°</span>
            </div>
            <div class="stat-row">
                <span class="stat-label">Root Chord</span>
                <span class="stat-value">{params['root_chord']:.2f} units</span>
            </div>
            <div class="stat-row">
                <span class="stat-label">Tip Chord</span>
                <span class="stat-value">{params['tip_chord']:.2f} units</span>
            </div>
            <div class="stat-row">
                <span class="stat-label">Root / Tip Thickness</span>
                <span class="stat-value">{params['root_th']:.2f} / {params['tip_th']:.2f}</span>
            </div>
            <div class="stat-row">
                <span class="stat-label">Hinge Line Location</span>
                <span class="stat-value">{params['w_hinge_line']*100:.1f}% chord</span>
            </div>
        </div>

        <div class="card">
            <div class="card-title">Tail Geometry</div>
            <div class="stat-row">
                <span class="stat-label">Configuration</span>
                <span class="stat-value">{params['tail_config'].capitalize()} ({num_fins} fins)</span>
            </div>
            <div class="stat-row">
                <span class="stat-label">Total Area</span>
                <span class="stat-value">{S_tail_total:.2f} units²</span>
            </div>
            <div class="stat-row">
                <span class="stat-label">Aspect Ratio</span>
                <span class="stat-value">{AR_tail:.2f}</span>
            </div>
            <div class="stat-row">
                <span class="stat-label">Taper Ratio</span>
                <span class="stat-value">{taper_tail:.3f}</span>
            </div>
            <div class="stat-row">
                <span class="stat-label">Sweep Angle</span>
                <span class="stat-value">{params['tail_sweep']:.2f}°</span>
            </div>
            <div class="stat-row">
                <span class="stat-label">Hinge Line Location</span>
                <span class="stat-value">{params['f_hinge_line']*100:.1f}% chord</span>
            </div>
        </div>
    </div>
    <div id="viewer"></div>

    <script>
        var figData = {fig_json};
        Plotly.newPlot('viewer', figData.data, figData.layout, {{responsive: true}});
    </script>
</body>
</html>
"""
    
    with open(output_file, 'w') as f:
        f.write(html_content)
    print(f"Plotly interactive HTML dashboard saved to: {output_file}")


def prompt_parameter(name, default_val):
    """
    Prompts the user for a parameter in the console.
    If the user presses Enter, returns the default value.
    """
    try:
        user_input = input(f"Enter {name} [{default_val}]: ").strip()
        if not user_input:
            return default_val
        if isinstance(default_val, float):
            return float(user_input)
        elif isinstance(default_val, int):
            return int(user_input)
        return user_input
    except (KeyboardInterrupt, EOFError):
        print(f"\nUsing default: {default_val}")
        return default_val
    except ValueError:
        print(f"Invalid input, using default: {default_val}")
        return default_val


def compute_geometry_metrics(params):
    """
    Computes summary aerodynamic-geometry metrics (lengths, areas,
    aspect ratios, taper ratios, volume) from a full vis-parameter dict.
    Used to drive numeric readouts alongside the 3D view.
    """
    L_total = params["nose_length"] + params["body_length"]
    R_b = params["body_diameter"] / 2.0
    V_body = np.pi * (R_b ** 2) * params["body_length"]
    V_nose = np.pi * (R_b ** 2) * params["nose_length"] * (1.0 / 3.0 + 0.167 * params["nose_bluntness"])
    V_total = V_body + V_nose

    S_wing_one = params["semi_span"] * (params["root_chord"] + params["tip_chord"]) / 2.0
    S_wing = 2.0 * S_wing_one
    AR_wing = (2.0 * params["semi_span"]) ** 2 / S_wing if S_wing > 0 else 0.0
    taper_wing = params["tip_chord"] / params["root_chord"] if params["root_chord"] > 0 else 0.0

    num_fins = 4 if params["tail_config"] == 'cruciform' else 3
    S_tail_one = params["tail_semi_span"] * (params["tail_root_chord"] + params["tail_tip_chord"]) / 2.0
    S_tail_total = num_fins * S_tail_one
    AR_tail = (2.0 * params["tail_semi_span"]) ** 2 / (2.0 * S_tail_one) if S_tail_one > 0 else 0.0
    taper_tail = params["tail_tip_chord"] / params["tail_root_chord"] if params["tail_root_chord"] > 0 else 0.0

    return {
        'total_length': L_total,
        'body_diameter': params["body_diameter"],
        'fineness_ratio': L_total / params["body_diameter"] if params["body_diameter"] > 0 else 0.0,
        'volume': V_total,
        'wingspan': 2.0 * params["semi_span"],
        'wing_area': S_wing,
        'wing_aspect_ratio': AR_wing,
        'wing_taper': taper_wing,
        'tail_span': 2.0 * params["tail_semi_span"],
        'tail_area': S_tail_total,
        'tail_aspect_ratio': AR_tail,
        'tail_taper': taper_tail,
        'num_tail_fins': num_fins,
    }


def build_geometry(params):
    """
    Generates the full 3D geometry mesh dict (nose, body, wings, tails,
    hinge lines) from a vis-parameter dict, without any plotting.
    Shared by the CLI visualizer and any embedded-canvas renderer.
    """
    params = dict(params)
    for k in ["nose_length", "nose_diameter", "body_length", "body_diameter",
              "wing_le", "root_chord", "tip_chord", "semi_span", "root_th", "tip_th",
              "tail_le", "tail_root_chord", "tail_tip_chord", "tail_semi_span",
              "tail_root_th", "tail_tip_th"]:
        params[k] = abs(params[k])
    params["wing_sweep"] = abs(params["wing_sweep"])
    params["tail_sweep"] = abs(params["tail_sweep"])
    for k in ["w_hinge_line", "f_hinge_line", "nose_bluntness"]:
        if params[k] > 1.0:
            params[k] = params[k] / 100.0
        params[k] = np.clip(params[k], 0.0, 1.0)

    X_nose, Y_nose, Z_nose = generate_nose(params["nose_length"], params["nose_diameter"], params["nose_bluntness"])
    X_body, Y_body, Z_body = generate_body(params["body_length"], params["body_diameter"], params["nose_length"])

    geometry = {
        'nose': (X_nose, Y_nose, Z_nose),
        'body': (X_body, Y_body, Z_body),
        'wings_tails': {}
    }
    hinge_lines = {}

    w_r_Xu, w_r_Yu, w_r_Zu, w_r_Xl, w_r_Yl, w_r_Zl, w_r_hl = generate_fin_panel(
        params["wing_le"], params["root_chord"], params["tip_chord"], params["semi_span"], params["wing_sweep"],
        params["root_th"], params["tip_th"], 0.0, params["w_hinge_line"]
    )
    geometry['wings_tails']['wing_right'] = [(w_r_Xu, w_r_Yu, w_r_Zu), (w_r_Xl, w_r_Yl, w_r_Zl)]
    hinge_lines['wing_right'] = w_r_hl

    w_l_Xu, w_l_Yu, w_l_Zu, w_l_Xl, w_l_Yl, w_l_Zl, w_l_hl = generate_fin_panel(
        params["wing_le"], params["root_chord"], params["tip_chord"], params["semi_span"], params["wing_sweep"],
        params["root_th"], params["tip_th"], 180.0, params["w_hinge_line"]
    )
    geometry['wings_tails']['wing_left'] = [(w_l_Xu, w_l_Yu, w_l_Zu), (w_l_Xl, w_l_Yl, w_l_Zl)]
    hinge_lines['wing_left'] = w_l_hl

    if params["tail_config"] == 'cruciform':
        phi_angles = [0.0, 90.0, 180.0, 270.0]
        names = ['tail_right', 'tail_top', 'tail_left', 'tail_bottom']
    else:
        phi_angles = [0.0, 90.0, 180.0]
        names = ['tail_right', 'tail_top', 'tail_left']

    for name, phi in zip(names, phi_angles):
        Xu, Yu, Zu, Xl, Yl, Zl, hl = generate_fin_panel(
            params["tail_le"], params["tail_root_chord"], params["tail_tip_chord"], params["tail_semi_span"],
            params["tail_sweep"], params["tail_root_th"], params["tail_tip_th"], phi, params["f_hinge_line"]
        )
        geometry['wings_tails'][name] = [(Xu, Yu, Zu), (Xl, Yl, Zl)]
        hinge_lines[name] = hl

    return geometry, hinge_lines, params


def _shaded_facecolors(X, Y, Z, base_rgb, ls_azdeg=315, ls_altdeg=45,
                       lo=0.55, hi=1.0):
    """
    Computes smooth per-facet facecolors using a light source, so the
    surface reads as a solid, gently shaded CAD part instead of a flat
    single-tone (which under Matplotlib's default 3D shading can look
    faceted / hollow, especially at grazing viewing angles).
    """
    ls = LightSource(azdeg=ls_azdeg, altdeg=ls_altdeg)
    try:
        rgb = ls.shade(Z, plt.cm.Greys, vert_exag=0.0, blend_mode='soft',
                       fraction=1.0)
        # shade() returns an RGBA image keyed off elevation; we only want
        # the intensity channel to modulate our own solid base color.
        intensity = rgb[..., 0]
        intensity = lo + (hi - lo) * (intensity - intensity.min()) / \
            max(intensity.max() - intensity.min(), 1e-9)
    except Exception:
        intensity = np.ones_like(Z)

    r, g, b = base_rgb
    facecolors = np.empty(Z.shape + (4,))
    facecolors[..., 0] = np.clip(r * intensity, 0, 1)
    facecolors[..., 1] = np.clip(g * intensity, 0, 1)
    facecolors[..., 2] = np.clip(b * intensity, 0, 1)
    facecolors[..., 3] = 1.0
    return facecolors


def _add_end_cap(ax, X, Y, Z, color, row=-1):
    """
    Closes off the open end of a tube-like surface (e.g. the aft end of
    the fuselage) with a solid filled disc, so the body reads as a solid
    closed shape instead of a hollow/see-through tube when viewed from
    behind or at an angle.
    """
    x_end = X[row, 0]
    ys = Y[row, :]
    zs = Z[row, :]
    y0, z0 = float(np.mean(ys)), float(np.mean(zs))
    n = len(ys)
    verts = []
    for i in range(n - 1):
        verts.append([
            (x_end, y0, z0),
            (x_end, ys[i], zs[i]),
            (x_end, ys[i + 1], zs[i + 1]),
        ])
    cap = Poly3DCollection(verts, facecolors=color, edgecolors='none',
                           alpha=1.0, shade=False)
    ax.add_collection3d(cap)


def render_geometry_on_figure(fig, params, title=None, large=False, bg_color=None,
                              render_mode='solid'):
    """
    Draws the aerodynamic body geometry described by `params` (a full
    vis-parameter dict) onto an existing Matplotlib `Figure` (e.g. one
    embedded in a Tk canvas via FigureCanvasTkAgg), clearing it first.
    Does NOT call plt.show()/plt.ion() and does NOT touch the module-level
    _fig/_ax used by plot_matplotlib(), so it is safe to use inside a GUI
    event loop alongside the CLI visualizer.

    `large=True` scales up fonts/linewidths for a big popup/zoom view.
    `bg_color` optionally matches the embedding GUI's panel background.
    `render_mode` is either 'solid' (fully covered, CAD-shaded surfaces --
    the default) or 'wireframe' (open mesh lines only, no fill), letting
    the caller flip between a "wired" skeletal view and a fully covered
    view of the same aero body.

    Returns the computed geometry metrics dict (see compute_geometry_metrics).
    """
    geometry, hinge_lines, full_params = build_geometry(params)

    wireframe = (render_mode == 'wireframe')

    fs_label = 13 if large else 10
    fs_title = 17 if large else 12
    fs_tick = 10 if large else 8
    lw_hinge = 2.2 if large else 1.4
    lw_wire = (1.1 if large else 0.7)
    wire_stride = 2 if large else 3

    face_bg = bg_color or '#EEF1F5'

    fig.clf()
    fig.patch.set_facecolor(face_bg)
    ax = fig.add_subplot(111, projection='3d')
    ax.set_facecolor(face_bg)

    # --- Clean CAD-style panes: soft neutral fill, subtle edges ---
    for pane in (ax.xaxis.pane, ax.yaxis.pane, ax.zaxis.pane):
        pane.set_facecolor((0.96, 0.97, 0.99, 1.0))
        pane.set_edgecolor((0.75, 0.78, 0.82, 1.0))
        pane.set_linewidth(0.6)
    ax.xaxis._axinfo["grid"]['color'] = (0.82, 0.85, 0.88, 0.6)
    ax.yaxis._axinfo["grid"]['color'] = (0.82, 0.85, 0.88, 0.6)
    ax.zaxis._axinfo["grid"]['color'] = (0.82, 0.85, 0.88, 0.6)

    if wireframe:
        # --- Wired / skeletal view: open mesh lines only, no fill ---
        X, Y, Z = geometry['nose']
        ax.plot_wireframe(X, Y, Z, color='#3B4652', linewidth=lw_wire,
                          rstride=wire_stride, cstride=wire_stride)

        X, Y, Z = geometry['body']
        ax.plot_wireframe(X, Y, Z, color='#3B4652', linewidth=lw_wire,
                          rstride=wire_stride, cstride=wire_stride)

        for part_name, surfaces in geometry['wings_tails'].items():
            is_wing = 'wing' in part_name
            color = '#2563EB' if is_wing else '#DC2626'
            for surface in surfaces:
                X, Y, Z = surface
                ax.plot_wireframe(X, Y, Z, color=color, linewidth=lw_wire,
                                  rstride=wire_stride, cstride=wire_stride)
    else:
        # --- Body surfaces: solid, smoothly-lit CAD-style shading ---
        X, Y, Z = geometry['nose']
        ax.plot_surface(X, Y, Z, facecolors=_shaded_facecolors(X, Y, Z, to_rgb('#D5D9DE')),
                        edgecolor='none', alpha=1.0, shade=False, antialiased=True,
                        rstride=1, cstride=1)

        X, Y, Z = geometry['body']
        ax.plot_surface(X, Y, Z, facecolors=_shaded_facecolors(X, Y, Z, to_rgb('#9AA3AD')),
                        edgecolor='none', alpha=1.0, shade=False, antialiased=True,
                        rstride=1, cstride=1)
        # Close the open aft end of the fuselage so it reads as a solid body
        # rather than a hollow tube when viewed from the rear / at an angle.
        _add_end_cap(ax, X, Y, Z, '#7C838C', row=-1)

        for part_name, surfaces in geometry['wings_tails'].items():
            is_wing = 'wing' in part_name
            color = '#2563EB' if is_wing else '#DC2626'
            for surface in surfaces:
                X, Y, Z = surface
                ax.plot_surface(X, Y, Z, facecolors=_shaded_facecolors(X, Y, Z, to_rgb(color), lo=0.65),
                                edgecolor='none', alpha=1.0, shade=False, antialiased=True,
                                rstride=1, cstride=1)

    for part_name, hl_data in hinge_lines.items():
        if hl_data:
            xu, yu, zu = hl_data['upper']
            ax.plot(xu, yu, zu, color='#F59E0B', linestyle='--', linewidth=lw_hinge)
            xl, yl, zl = hl_data['lower']
            ax.plot(xl, yl, zl, color='#F59E0B', linestyle='--', linewidth=lw_hinge)

    ax.set_xlabel('X — Length', fontsize=fs_label, fontweight='bold', color='#334155', labelpad=10)
    ax.set_ylabel('Y — Span', fontsize=fs_label, fontweight='bold', color='#334155', labelpad=10)
    ax.set_zlabel('Z — Height', fontsize=fs_label, fontweight='bold', color='#334155', labelpad=8)
    ax.set_title(title or 'Aerodynamic Body 3D View',
                fontsize=fs_title, fontweight='bold', color='#0F172A', pad=14)
    ax.tick_params(labelsize=fs_tick, colors='#475569')

    # Pleasant 3/4 CAD-style viewing angle
    ax.view_init(elev=22, azim=-58)

    X_all = np.concatenate([geometry['nose'][0].flatten(), geometry['body'][0].flatten()])
    Y_all = np.concatenate([geometry['nose'][1].flatten(), geometry['body'][1].flatten()])
    Z_all = np.concatenate([geometry['nose'][2].flatten(), geometry['body'][2].flatten()])

    max_range = np.array([X_all.max() - X_all.min(),
                          Y_all.max() - Y_all.min(),
                          Z_all.max() - Z_all.min()]).max() / 2.0
    max_range = max(max_range, 1e-6)
    mid_x = (X_all.max() + X_all.min()) * 0.5
    mid_y = (Y_all.max() + Y_all.min()) * 0.5
    mid_z = (Z_all.max() + Z_all.min()) * 0.5
    ax.set_xlim(mid_x - max_range, mid_x + max_range)
    ax.set_ylim(mid_y - max_range, mid_y + max_range)
    ax.set_zlim(mid_z - max_range, mid_z + max_range)
    ax.grid(True, alpha=0.4)

    try:
        ax.set_box_aspect((1, 1, 1))
    except Exception:
        pass

    fig.tight_layout()

    return compute_geometry_metrics(full_params)


def visualize_aero_body(**kwargs):
    """
    Generate and display/save the 3D aerodynamic body visualization.
    If a Matplotlib 3D window is already open, updates it in-place.
    """
    # Standard default values
    defaults = {
        "nose_length": 2.0,
        "nose_diameter": 0.5,
        "nose_bluntness": 0.2,
        "body_length": 5.0,
        "body_diameter": 0.5,
        "wing_le": 3.0,
        "root_chord": 1.5,
        "tip_chord": 0.5,
        "semi_span": 2.0,
        "w_hinge_line": 0.7,
        "root_th": 0.08,
        "tip_th": 0.03,
        "wing_sweep": 30.0,
        "tail_le": 6.0,
        "tail_root_chord": 1.0,
        "tail_tip_chord": 0.3,
        "tail_sweep": 45.0,
        "tail_semi_span": 1.0,
        "f_hinge_line": 0.75,
        "tail_root_th": 0.05,
        "tail_tip_th": 0.02,
        "tail_config": "cruciform",
        "png_out": "aero_body.png",
        "html_out": "aero_body.html",
        "show": True,
        "block": False
    }

    params = defaults.copy()
    params.update(kwargs)

    # Ensure all dimensions/lengths/sweeps are positive and hinge lines/bluntness are fractional
    for k in ["nose_length", "nose_diameter", "body_length", "body_diameter", 
              "wing_le", "root_chord", "tip_chord", "semi_span", "root_th", "tip_th", 
              "tail_le", "tail_root_chord", "tail_tip_chord", "tail_semi_span", 
              "tail_root_th", "tail_tip_th"]:
        params[k] = abs(params[k])
        
    params["wing_sweep"] = abs(params["wing_sweep"])
    params["tail_sweep"] = abs(params["tail_sweep"])
    
    # Hinge lines and bluntness inputs - if > 1.0, assume they entered it as percentage (e.g. 60 instead of 0.6)
    for k in ["w_hinge_line", "f_hinge_line", "nose_bluntness"]:
        if params[k] > 1.0:
            params[k] = params[k] / 100.0
        params[k] = np.clip(params[k], 0.0, 1.0)

    # Generate geometry meshes
    
    # 1. Nose
    X_nose, Y_nose, Z_nose = generate_nose(params["nose_length"], params["nose_diameter"], params["nose_bluntness"])
    
    # 2. Body (starts at the end of the nose)
    X_body, Y_body, Z_body = generate_body(params["body_length"], params["body_diameter"], params["nose_length"])
    
    geometry = {
        'nose': (X_nose, Y_nose, Z_nose),
        'body': (X_body, Y_body, Z_body),
        'wings_tails': {}
    }
    
    hinge_lines = {}
    
    # 3. Wings (Symmetric horizontal, rotation angle = 0 and 180)
    # Right Wing (phi = 0)
    w_r_Xu, w_r_Yu, w_r_Zu, w_r_Xl, w_r_Yl, w_r_Zl, w_r_hl = generate_fin_panel(
        params["wing_le"], params["root_chord"], params["tip_chord"], params["semi_span"], params["wing_sweep"],
        params["root_th"], params["tip_th"], 0.0, params["w_hinge_line"]
    )
    geometry['wings_tails']['wing_right'] = [
        (w_r_Xu, w_r_Yu, w_r_Zu), (w_r_Xl, w_r_Yl, w_r_Zl)
    ]
    hinge_lines['wing_right'] = w_r_hl
    
    # Left Wing (phi = 180)
    w_l_Xu, w_l_Yu, w_l_Zu, w_l_Xl, w_l_Yl, w_l_Zl, w_l_hl = generate_fin_panel(
        params["wing_le"], params["root_chord"], params["tip_chord"], params["semi_span"], params["wing_sweep"],
        params["root_th"], params["tip_th"], 180.0, params["w_hinge_line"]
    )
    geometry['wings_tails']['wing_left'] = [
        (w_l_Xu, w_l_Yu, w_l_Zu), (w_l_Xl, w_l_Yl, w_l_Zl)
    ]
    hinge_lines['wing_left'] = w_l_hl

    # 4. Tail Fins
    if params["tail_config"] == 'cruciform':
        # 4 symmetric fins at 0, 90, 180, 270 degrees
        phi_angles = [0.0, 90.0, 180.0, 270.0]
        names = ['tail_right', 'tail_top', 'tail_left', 'tail_bottom']
    else:
        # Standard aircraft tail: horizontal stabilizers (0, 180) and single vertical stabilizer (90)
        phi_angles = [0.0, 90.0, 180.0]
        names = ['tail_right', 'tail_top', 'tail_left']
        
    for name, phi in zip(names, phi_angles):
        Xu, Yu, Zu, Xl, Yl, Zl, hl = generate_fin_panel(
            params["tail_le"], params["tail_root_chord"], params["tail_tip_chord"], params["tail_semi_span"], params["tail_sweep"],
            params["tail_root_th"], params["tail_tip_th"], phi, params["f_hinge_line"]
        )
        geometry['wings_tails'][name] = [
            (Xu, Yu, Zu), (Xl, Yl, Zl)
        ]
        hinge_lines[name] = hl
        
    # Generate Plots
    plot_matplotlib(geometry, hinge_lines, params["png_out"], show=params["show"], block=params["block"])
    if PLOTLY_AVAILABLE and params["html_out"]:
        plot_plotly(geometry, hinge_lines, params, params["html_out"])


def main():
    print("========================================")
    print("   Aerodynamic Body 3D Visualizer")
    print("========================================")
    
    # Standard default values
    defaults = {
        "nose_length": 2.0,
        "nose_diameter": 0.5,
        "nose_bluntness": 0.2,
        "body_length": 5.0,
        "body_diameter": 0.5,
        "wing_le": 3.0,
        "root_chord": 1.5,
        "tip_chord": 0.5,
        "semi_span": 2.0,
        "w_hinge_line": 0.7,
        "root_th": 0.08,
        "tip_th": 0.03,
        "wing_sweep": 30.0,
        "tail_le": 6.0,
        "tail_root_chord": 1.0,
        "tail_tip_chord": 0.3,
        "tail_sweep": 45.0,
        "tail_semi_span": 1.0,
        "f_hinge_line": 0.75,
        "tail_root_th": 0.05,
        "tail_tip_th": 0.02,
        "tail_config": "cruciform",
        "png_out": "aero_body.png",
        "html_out": "aero_body.html"
    }

    try:
        use_interactive = input("Would you like to input parameters interactively? (y/n) [n]: ").strip().lower() == 'y'
    except (KeyboardInterrupt, EOFError):
        use_interactive = False
        print("\nUsing defaults.")

    params = {}
    if use_interactive:
        print("\nEnter parameter values (press Enter to accept default):")
        params["nose_length"] = prompt_parameter("nose length", defaults["nose_length"])
        params["nose_diameter"] = prompt_parameter("nose diameter", defaults["nose_diameter"])
        params["nose_bluntness"] = prompt_parameter("nose bluntness (0.0=sharp, 1.0=hemisphere)", defaults["nose_bluntness"])
        params["body_length"] = prompt_parameter("body length", defaults["body_length"])
        params["body_diameter"] = prompt_parameter("body diameter", defaults["body_diameter"])
        
        params["wing_le"] = prompt_parameter("wing leading edge (le)", defaults["wing_le"])
        params["root_chord"] = prompt_parameter("wing root chord", defaults["root_chord"])
        params["tip_chord"] = prompt_parameter("wing tip chord", defaults["tip_chord"])
        params["semi_span"] = prompt_parameter("wing semi-span", defaults["semi_span"])
        params["w_hinge_line"] = prompt_parameter("wing hinge line (fraction)", defaults["w_hinge_line"])
        params["root_th"] = prompt_parameter("wing root thickness (root th)", defaults["root_th"])
        params["tip_th"] = prompt_parameter("wing tip thickness (tip th)", defaults["tip_th"])
        params["wing_sweep"] = prompt_parameter("wing sweep (degrees)", defaults["wing_sweep"])
        
        params["tail_le"] = prompt_parameter("tail leading edge (taile le)", defaults["tail_le"])
        params["tail_root_chord"] = prompt_parameter("tail root chord (root chord.1)", defaults["tail_root_chord"])
        params["tail_tip_chord"] = prompt_parameter("tail tip chord (tip chod.1)", defaults["tail_tip_chord"])
        params["tail_sweep"] = prompt_parameter("tail sweep", defaults["tail_sweep"])
        params["tail_semi_span"] = prompt_parameter("tail semi-span (sei-span.1)", defaults["tail_semi_span"])
        params["f_hinge_line"] = prompt_parameter("tail hinge line (f hinge line)", defaults["f_hinge_line"])
        params["tail_root_th"] = prompt_parameter("tail root thickness (root th.1)", defaults["tail_root_th"])
        params["tail_tip_th"] = prompt_parameter("tail tip thickness (tip th.1)", defaults["tail_tip_th"])
        
        try:
            tail_config_input = input(f"tail configuration (cruciform/aircraft) [{defaults['tail_config']}]: ").strip().lower()
        except (KeyboardInterrupt, EOFError):
            tail_config_input = ""
        params["tail_config"] = tail_config_input if tail_config_input in ['cruciform', 'aircraft'] else defaults['tail_config']
        
        params["png_out"] = defaults["png_out"]
        params["html_out"] = defaults["html_out"]
        params["show"] = True
    else:
        # Fallback to argparse
        parser = argparse.ArgumentParser(description="Aerodynamic Body 3D Visualizer")
        parser.add_argument("--nose-length", type=float, default=defaults["nose_length"])
        parser.add_argument("--nose-diameter", type=float, default=defaults["nose_diameter"])
        parser.add_argument("--nose-bluntness", type=float, default=defaults["nose_bluntness"])
        parser.add_argument("--body-length", type=float, default=defaults["body_length"])
        parser.add_argument("--body-diameter", type=float, default=defaults["body_diameter"])
        parser.add_argument("--wing-le", type=float, default=defaults["wing_le"])
        parser.add_argument("--root-chord", type=float, default=defaults["root_chord"])
        parser.add_argument("--tip-chord", type=float, default=defaults["tip_chord"])
        parser.add_argument("--semi-span", type=float, default=defaults["semi_span"])
        parser.add_argument("--w-hinge-line", type=float, default=defaults["w_hinge_line"])
        parser.add_argument("--root-th", type=float, default=defaults["root_th"])
        parser.add_argument("--tip-th", type=float, default=defaults["tip_th"])
        parser.add_argument("--wing-sweep", type=float, default=defaults["wing_sweep"])
        parser.add_argument("--tail-le", type=float, default=defaults["tail_le"])
        parser.add_argument("--tail-root-chord", type=float, default=defaults["tail_root_chord"])
        parser.add_argument("--tail-tip-chord", type=float, default=defaults["tail_tip_chord"])
        parser.add_argument("--tail-sweep", type=float, default=defaults["tail_sweep"])
        parser.add_argument("--tail-semi-span", type=float, default=defaults["tail_semi_span"])
        parser.add_argument("--f-hinge-line", type=float, default=defaults["f_hinge_line"])
        parser.add_argument("--tail-root-th", type=float, default=defaults["tail_root_th"])
        parser.add_argument("--tail-tip-th", type=float, default=defaults["tail_tip_th"])
        parser.add_argument("--tail-config", type=str, choices=['cruciform', 'aircraft'], default=defaults["tail_config"])
        parser.add_argument("--png-out", type=str, default=defaults["png_out"])
        parser.add_argument("--html-out", type=str, default=defaults["html_out"])
        parser.add_argument("--no-show", action="store_true", help="Do not display the plot window")
        
        args = parser.parse_args()
        params = vars(args)
        params["show"] = not args.no_show

    # In standalone CLI execution, we block on plt.show()
    params["block"] = params["show"]
    
    print("\nGenerating and displaying visualizations...")
    visualize_aero_body(**params)
    print("Done!")


if __name__ == "__main__":
    main()