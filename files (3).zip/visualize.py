#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
visualize.py  —  DRDL Aerospace AI Platform
========================================================================
Adapter layer between the GUI's 18-parameter dict (PARAMS in app.py)
and aero_body.py's 3-D geometry generator.

The XGBoost surrogate model (predictor.py) was trained on a
slender-body abstraction that never carried fuselage/nose diameter or
nose bluntness, so those three quantities cannot come from the model.
Per team decision, they are AUTO-DERIVED from the existing geometry
parameters using fixed, documented engineering ratios below — no new
GUI input fields are required.

Public API
----------
expand_params(params)          -> dict   (adds body_diameter / nose_diameter / nose_bluntness)
build_geometry(params)         -> (nose, body, fins, expanded_params)
geometry_stats(params)         -> dict   (fuselage + wing + tail stats)
build_geometry_figure(params, alpha_deg=0.0, ...) -> matplotlib.figure.Figure
========================================================================
"""

import math
from typing import Any, Dict, Tuple

import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401  (registers 3-D projection)

from aero_body import (generate_nose, generate_body, generate_fin_panel,
                        _fuselage_stats, _fin_stats)

# =========================================================
# AUTO-DERIVATION CONSTANTS  (fixed, no new GUI fields)
# =========================================================
FINENESS_RATIO = 9.0   # body_diameter = body_len / FINENESS_RATIO
NOSE_BLUNTNESS = 0.08  # 8% spherical-cap blunting on the nose tip


def _derive_body_diameter(body_len: float) -> float:
    """body_diameter = body_len / FINENESS_RATIO (typical slender-body ratio)."""
    return float(body_len) / FINENESS_RATIO


def expand_params(params: Dict[str, Any]) -> Dict[str, Any]:
    """Return a copy of ``params`` with body_diameter/nose_diameter/nose_bluntness added."""
    p = dict(params)
    p['body_diameter'] = _derive_body_diameter(p['body_len'])
    p['nose_diameter'] = p['body_diameter']       # nose meets body flush
    p['nose_bluntness'] = NOSE_BLUNTNESS
    return p


def build_geometry(params: Dict[str, Any]):
    """
    Build the nose, body, and 4 fin-panel meshes (2 wing + 2 tail,
    right/left) from a GUI params dict. Returns (nose, body, fins, p)
    where ``p`` is the expanded parameter dict actually used.
    """
    p = expand_params(params)

    nose = generate_nose(p['nose_len'], p['nose_diameter'], p['nose_bluntness'])
    body = generate_body(p['body_len'], p['body_diameter'], p['nose_len'])

    fins = []
    for side in ('right', 'left'):
        fins.append(generate_fin_panel(
            p['wing_le'], p['root_chord'], p['tip_chord'], p['semi_span'],
            p['wing_le'], p['root_th'], p['tip_th'], p['wing_sweep'],
            p['body_diameter'], side=side))
    for side in ('right', 'left'):
        fins.append(generate_fin_panel(
            p['tail_le'], p['root_chord1'], p['tip_chord1'], p['semi_span1'],
            p['tail_le'], p['root_th1'], p['tip_th1'], 0.0,
            p['body_diameter'], side=side))

    return nose, body, fins, p


def geometry_stats(params: Dict[str, Any]) -> Dict[str, float]:
    """Fuselage + wing + tail derived statistics for the sidebar display."""
    p = expand_params(params)
    stats: Dict[str, float] = {}
    stats.update(_fuselage_stats(p['nose_len'], p['body_len'], p['body_diameter']))
    stats.update({f'wing_{k}': v for k, v in _fin_stats(
        p['root_chord'], p['tip_chord'], p['semi_span'],
        p['root_th'], p['tip_th']).items()})
    stats.update({f'tail_{k}': v for k, v in _fin_stats(
        p['root_chord1'], p['tip_chord1'], p['semi_span1'],
        p['root_th1'], p['tip_th1']).items()})
    stats['body_diameter_mm'] = round(p['body_diameter'], 2)
    stats['nose_bluntness'] = p['nose_bluntness']
    return stats


def _rotate_pitch(X: np.ndarray, Y: np.ndarray, Z: np.ndarray, alpha_deg: float
                   ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Rigid pitch rotation about the Y axis — DISPLAY ONLY, for angle-of-attack
    visualisation during a Flight-Envelope alpha sweep. Geometry itself is
    unchanged; only the rendered attitude changes."""
    a = math.radians(alpha_deg)
    ca, sa = math.cos(a), math.sin(a)
    Xr = X * ca + Z * sa
    Zr = -X * sa + Z * ca
    return Xr, Y, Zr


def build_geometry_figure(params: Dict[str, Any], alpha_deg: float = 0.0,
                           title: str = '3-D Aerodynamic Body',
                           highlight: str = None,
                           bg: str = '#0B0F1A', panel_bg: str = '#1C2333',
                           text_color: str = '#F1F5F9'):
    """
    Build a dark-themed matplotlib 3-D Figure of the airframe, styled to
    match the GUI palette, ready for FigureCanvasTkAgg embedding.

    alpha_deg : rigid pitch (deg) applied for display only — used by the
                Flight-Envelope tab to visualise angle of attack.
    highlight : optional short string (e.g. 'RANK #2') stamped into the
                title, used by the Optimizer tab's Top-5 viewer.
    """
    nose, body, fins, p = build_geometry(params)

    fig = plt.figure(figsize=(9, 4.2))
    fig.patch.set_facecolor(bg)
    ax = fig.add_subplot(111, projection='3d')
    ax.set_facecolor(panel_bg)

    face_colors = ('#3B82F6', '#06B6D4', '#F59E0B')
    for mesh, color in ((nose, face_colors[0]), (body, face_colors[1])):
        X, Y, Z = mesh
        if abs(alpha_deg) > 1e-6:
            X, Y, Z = _rotate_pitch(X, Y, Z, alpha_deg)
        ax.plot_surface(X, Y, Z, color=color, alpha=0.9,
                         linewidth=0, antialiased=True)

    for X, Y, Z in fins:
        if abs(alpha_deg) > 1e-6:
            X, Y, Z = _rotate_pitch(X, Y, Z, alpha_deg)
        ax.plot_surface(X, Y, Z, color=face_colors[2], alpha=0.95,
                         linewidth=0, antialiased=True)

    all_x = np.concatenate([nose[0].ravel(), body[0].ravel()] +
                            [f[0].ravel() for f in fins])
    span = max(all_x.max() - all_x.min(), 1.0)
    ax.set_box_aspect((span, span * 0.35, span * 0.35))
    ax.set_xlabel('X (mm)', color=text_color, fontsize=8)
    ax.set_ylabel('Y (mm)', color=text_color, fontsize=8)
    ax.set_zlabel('Z (mm)', color=text_color, fontsize=8)
    ax.tick_params(colors=text_color, labelsize=7)

    ttl = title
    if highlight:
        ttl = f'{title}  —  {highlight}'
    if abs(alpha_deg) > 1e-6:
        ttl += f'   (alpha = {alpha_deg:.1f} deg)'
    ax.set_title(ttl, color='#06B6D4', fontsize=10, fontweight='bold')
    ax.view_init(elev=16, azim=-58)
    fig.tight_layout()
    return fig
