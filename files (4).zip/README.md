# Aero Body Designer — 3-D Geometry Studio

A professional PySimpleGUI desktop GUI built on top of the original
`aero_body.py` geometry engine (nose cone + fuselage + fin panel generator).

## Setup

```bash
pip install numpy matplotlib plotly PySimpleGUI
```

PySimpleGUI wraps tkinter, so on Linux you may also need the system tkinter
package if it isn't already installed: `sudo apt install python3-tk` (Debian/
Ubuntu) or the equivalent for your distro. Windows and macOS Python installs
normally include tkinter already.

Note on PySimpleGUI licensing: after a stint requiring a paid license
(2024–2025), PySimpleGUI 6 (2026) is free and open source again under LGPL3,
so a plain `pip install PySimpleGUI` is all you need.

## Run

```bash
python3 aero_body_gui.py
```

Keep `aero_body.py` and `aero_body_gui.py` in the same folder — the GUI
imports the geometry functions from the original module rather than
duplicating them.

## What's new vs. the original CLI script

| Original (`aero_body.py`)                | GUI (`aero_body_gui.py`)                                              |
|-------------------------------------------|-------------------------------------------------------------------------|
| CLI args or line-by-line terminal prompts | Tabbed parameter panel (Fuselage / Wing / Tail) with slider + numeric input for every field |
| One-shot PNG + HTML render                | **Live** 3-D preview that updates as you drag a slider (redraw on every change) |
| No shape analysis beyond summary stats    | **Cross-sectional area distribution chart** (area-rule plot)            |
| No mesh export                            | **STL export** (ASCII, triangulated) for CAD / slicers / 3-D viewers    |
| No saved configurations                   | **JSON preset system** — save/load, plus 4 built-in starting presets in a dropdown |
| No way to compare two designs             | **Baseline overlay** — snapshot a design, ghost it under your live edits |
| Plain terminal output                     | Live stats table, status bar feedback, dark professional theme          |
| Blocking script                           | STL export runs on a background thread with a progress popup            |

## Features in detail

- **Live 3-D preview** — matplotlib canvas embedded in the window (via
  `FigureCanvasTkAgg`), with the standard pan/zoom/rotate toolbar underneath.
  Toggle **View → Toggle Wireframe** (or the checkbox) for a see-through
  view, or **View → Reset Camera** to snap back to the default angle.
  Every field has both a slider and a linked numeric text box — drag or
  type, they stay in sync and the 3-D view redraws immediately.
- **Area distribution chart** — computed directly from the existing nose/body
  meshes (`π · r_max(x)²` at each axial station); no new physics, purely a
  geometric read-out of the shape you already generated.
- **Presets** — `File → Open/Save Preset` reads/writes a plain JSON dict of
  parameters, so configurations are portable and diffable. The preset
  dropdown in the left panel has four generic starting shapes.
- **Baseline comparison** — `Compare → Set Current as Baseline` snapshots the
  active geometry; check "Show baseline overlay" to see it as a translucent
  gray wireframe alongside your current edits, on both the 3-D view and the
  area chart.
- **STL export** — triangulates every surface (nose, body, all fin panels)
  into a combined ASCII STL file, runs off the UI thread with a progress bar.
- **Validation** — invalid values (e.g. non-positive lengths) show a status
  bar warning instead of crashing; the last good geometry stays on screen.

## Notes

- This GUI only wraps the existing geometric surface generator — it doesn't
  add or change any aerodynamic performance modeling. The area-rule chart is
  a shape-only visualization (cross-sectional area vs. length), same as
  what's taught in any intro aerodynamics course.
- Tested end-to-end under a virtual display (Xvfb): window construction,
  slider/input edits triggering live recompute, preset loading, baseline
  set/clear, and STL export all verified working, with a screenshot
  confirming the layout renders correctly.
