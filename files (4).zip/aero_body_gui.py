#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
aero_body_gui.py — Professional desktop GUI for the aero_body geometry engine
================================================================================
A PySimpleGUI front-end for aero_body.py (nose + fuselage + fin panel
generator). PySimpleGUI 5/6 is free/LGPL3 again (pip install PySimpleGUI).

Adds, on top of the original CLI/script:
  * Live embedded 3-D preview (matplotlib canvas inside the window) —
    updates whenever you edit a parameter (debounced).
  * Cross-sectional area distribution plot (classic "area rule" chart),
    computed directly from the existing surface meshes — geometry only.
  * STL export (ASCII, triangulated) for CAD / slicers / 3-D viewers, run
    on a background thread with a progress popup.
  * JSON preset system: save/load named configurations, plus several
    built-in starting presets in a dropdown.
  * Baseline comparison: snapshot the current shape and overlay it as a
    translucent ghost wireframe against your current edits.
  * Live statistics table (fineness ratio, volume, wetted area, aspect
    ratio, taper ratio, etc.).
  * Input validation with status-bar feedback, dark professional theme.

Run:
    pip install numpy matplotlib plotly PySimpleGUI
    python3 aero_body_gui.py

Requires aero_body.py to be importable (same directory / PYTHONPATH).
================================================================================
"""

import os
import sys
import json
import math
import threading
import queue
from typing import Any, Dict, List, Tuple, Optional

import numpy as np

import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.figure import Figure
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401

import tkinter as tk
import PySimpleGUI as sg

import aero_body as ab

APP_TITLE = "Aero Body Designer — 3-D Geometry Studio"
sg.theme("DarkBlue14")

# ----------------------------------------------------------------------------
# Field metadata: (label, key, min, max, step, decimals, tooltip)
# ----------------------------------------------------------------------------
FUSELAGE_FIELDS = [
    ("Nose length (mm)",     "nose_len",       1.0,  20000.0, 10.0, 1, "Axial length of the nose section."),
    ("Body diameter (mm)",   "body_diameter",  1.0,  10000.0, 5.0,  1, "Fuselage (and nose base) diameter."),
    ("Nose bluntness",       "nose_bluntness", 0.0,  0.99,    0.01, 3, "Spherical-cap radius as a fraction of the base radius. 0 = sharp cone."),
    ("Body length (mm)",     "body_len",       1.0,  50000.0, 10.0, 1, "Axial length of the cylindrical fuselage section."),
]
WING_FIELDS = [
    ("Leading edge @ (mm)",  "wing_le",     0.0, 50000.0, 10.0, 1, "Axial position of the wing root leading edge."),
    ("Root chord (mm)",      "root_chord",  1.0, 5000.0,  5.0,  1, "Chord length at the body-side root."),
    ("Tip chord (mm)",       "tip_chord",   1.0, 5000.0,  5.0,  1, "Chord length at the panel tip."),
    ("Semi-span (mm)",       "semi_span",   1.0, 5000.0,  5.0,  1, "Panel span measured from the body surface."),
    ("Root thickness (mm)",  "root_th",     0.1, 500.0,   1.0,  2, "Maximum biconvex thickness at the root."),
    ("Tip thickness (mm)",   "tip_th",      0.1, 500.0,   1.0,  2, "Maximum biconvex thickness at the tip."),
    ("Sweep angle (deg)",    "wing_sweep",  0.0, 75.0,    0.5,  2, "Leading-edge sweep angle."),
]
TAIL_FIELDS = [
    ("Leading edge @ (mm)",  "tail_le",      0.0, 50000.0, 10.0, 1, "Axial position of the tail root leading edge."),
    ("Root chord (mm)",      "root_chord1",  1.0, 5000.0,  5.0,  1, "Chord length at the body-side root."),
    ("Tip chord (mm)",       "tip_chord1",   1.0, 5000.0,  5.0,  1, "Chord length at the panel tip."),
    ("Semi-span (mm)",       "semi_span1",   1.0, 5000.0,  5.0,  1, "Panel span measured from the body surface."),
    ("Root thickness (mm)",  "root_th1",     0.1, 500.0,   1.0,  2, "Maximum biconvex thickness at the root."),
    ("Tip thickness (mm)",   "tip_th1",      0.1, 500.0,   1.0,  2, "Maximum biconvex thickness at the tip."),
]
ALL_FIELDS = FUSELAGE_FIELDS + WING_FIELDS + TAIL_FIELDS

BUILTIN_PRESETS: Dict[str, Dict[str, Any]] = {
    "Default (cruciform)": dict(ab.DEFAULTS, body_diameter=300.0),
    "Slender sounding rocket": dict(
        nose_len=450.0, nose_diameter=180.0, nose_bluntness=0.03,
        body_len=4200.0, body_diameter=180.0,
        wing_le=3600.0, root_chord=260.0, tip_chord=140.0, semi_span=260.0,
        root_th=12.0, tip_th=4.0, wing_sweep=35.0,
        tail_le=3600.0, root_chord1=260.0, tip_chord1=140.0, semi_span1=260.0,
        root_th1=12.0, tip_th1=4.0, layout="conventional"),
    "Wide-body cruciform test article": dict(
        nose_len=350.0, nose_diameter=420.0, nose_bluntness=0.15,
        body_len=2600.0, body_diameter=420.0,
        wing_le=1400.0, root_chord=320.0, tip_chord=220.0, semi_span=520.0,
        root_th=24.0, tip_th=8.0, wing_sweep=8.0,
        tail_le=2750.0, root_chord1=180.0, tip_chord1=90.0, semi_span1=220.0,
        root_th1=14.0, tip_th1=5.0, layout="cruciform"),
    "Blunt-nose reentry shape": dict(
        nose_len=220.0, nose_diameter=500.0, nose_bluntness=0.55,
        body_len=1800.0, body_diameter=500.0,
        wing_le=1500.0, root_chord=200.0, tip_chord=150.0, semi_span=300.0,
        root_th=20.0, tip_th=6.0, wing_sweep=15.0,
        tail_le=1900.0, root_chord1=140.0, tip_chord1=70.0, semi_span1=180.0,
        root_th1=12.0, tip_th1=4.0, layout="cruciform"),
}

DARK_BG = "#10131C"
PANEL_BG = "#151926"


# ============================================================================
# STL EXPORT (mesh triangulation + ASCII STL writer)
# ============================================================================
def surface_to_triangles(X: np.ndarray, Y: np.ndarray, Z: np.ndarray) -> List[Tuple]:
    """Triangulate a structured (rows, cols) surface grid into a flat
    list of ((x,y,z),(x,y,z),(x,y,z)) triangles."""
    rows, cols = X.shape
    tris = []
    for r in range(rows - 1):
        for c in range(cols - 1):
            p1 = (X[r, c],     Y[r, c],     Z[r, c])
            p2 = (X[r, c+1],   Y[r, c+1],   Z[r, c+1])
            p3 = (X[r+1, c],   Y[r+1, c],   Z[r+1, c])
            p4 = (X[r+1, c+1], Y[r+1, c+1], Z[r+1, c+1])
            tris.append((p1, p2, p3))
            tris.append((p2, p4, p3))
    return tris


def _tri_normal(p1, p2, p3) -> Tuple[float, float, float]:
    v1 = np.subtract(p2, p1)
    v2 = np.subtract(p3, p1)
    n = np.cross(v1, v2)
    norm = np.linalg.norm(n)
    if norm < 1e-12:
        return (0.0, 0.0, 0.0)
    n = n / norm
    return float(n[0]), float(n[1]), float(n[2])


def write_stl_ascii(triangles: List[Tuple], path: str, solid_name: str = "aero_body") -> None:
    with open(path, "w") as f:
        f.write(f"solid {solid_name}\n")
        for (p1, p2, p3) in triangles:
            nx, ny, nz = _tri_normal(p1, p2, p3)
            f.write(f" facet normal {nx:.6e} {ny:.6e} {nz:.6e}\n")
            f.write("  outer loop\n")
            for p in (p1, p2, p3):
                f.write(f"   vertex {p[0]:.6e} {p[1]:.6e} {p[2]:.6e}\n")
            f.write("  endloop\n endfacet\n")
        f.write(f"endsolid {solid_name}\n")


def export_stl(nose, body, fins, path: str, progress_cb=None) -> None:
    """Build the combined triangle mesh for nose + body + all fins and
    write it out as an ASCII STL file. progress_cb(pct:int) optional."""
    all_tris: List[Tuple] = []
    parts = [nose, body] + list(fins)
    for i, surf in enumerate(parts):
        all_tris.extend(surface_to_triangles(*surf))
        if progress_cb:
            progress_cb(int(100 * (i + 1) / len(parts)))
    write_stl_ascii(all_tris, path)


# ============================================================================
# Geometric analysis helpers (area-rule distribution)
# ============================================================================
def area_distribution(nose, body) -> Tuple[np.ndarray, np.ndarray]:
    """Cross-sectional area vs. axial station for the body-of-revolution
    parts (nose + fuselage). Purely geometric — pi * r_max(x)^2."""
    stations: List[float] = []
    areas: List[float] = []
    for X, Y, Z in (nose, body):
        r = np.sqrt(Y ** 2 + Z ** 2)
        r_max = r.max(axis=1)
        x_col = X[:, 0]
        stations.extend(x_col.tolist())
        areas.extend((math.pi * r_max ** 2).tolist())
    stations_arr = np.array(stations)
    areas_arr = np.array(areas)
    order = np.argsort(stations_arr)
    return stations_arr[order], areas_arr[order]


def build_geometry(params: Dict[str, Any]):
    """Run the aero_body engine for a parameter set and return
    (nose, body, fins, stats). Raises ValueError on invalid input."""
    p = dict(params)
    if p.get("nose_diameter") in (None, 0):
        p["nose_diameter"] = p["body_diameter"]

    layout = p.get("layout", "cruciform")
    sides = ("right", "left", "top", "bottom") if layout == "cruciform" else ("right", "left")

    nose = ab.generate_nose(p["nose_len"], p["nose_diameter"], p["nose_bluntness"])
    body = ab.generate_body(p["body_len"], p["body_diameter"], p["nose_len"])

    fins = []
    for s in sides:
        fins.append(ab.generate_fin_panel(
            p["wing_le"], p["root_chord"], p["tip_chord"], p["semi_span"],
            p["wing_le"], p["root_th"], p["tip_th"], p["wing_sweep"],
            p["body_diameter"], side=s))
    for s in sides:
        fins.append(ab.generate_fin_panel(
            p["tail_le"], p["root_chord1"], p["tip_chord1"], p["semi_span1"],
            p["tail_le"], p["root_th1"], p["tip_th1"], 0.0,
            p["body_diameter"], side=s))

    stats: Dict[str, Any] = {}
    stats.update(ab._fuselage_stats(p["nose_len"], p["body_len"], p["body_diameter"]))
    stats.update({f"wing_{k}": v for k, v in ab._fin_stats(
        p["root_chord"], p["tip_chord"], p["semi_span"], p["root_th"], p["tip_th"]).items()})
    stats.update({f"tail_{k}": v for k, v in ab._fin_stats(
        p["root_chord1"], p["tip_chord1"], p["semi_span1"], p["root_th1"], p["tip_th1"]).items()})
    return nose, body, fins, stats


# ============================================================================
# Background STL export (keeps UI responsive) — thread + queue instead of
# Qt's signal/slot, since PySimpleGUI uses tkinter's single-threaded loop.
# ============================================================================
def stl_export_thread(nose, body, fins, path, result_queue: "queue.Queue"):
    try:
        def progress_cb(pct):
            result_queue.put(("progress", pct))
        export_stl(nose, body, fins, path, progress_cb=progress_cb)
        result_queue.put(("done", path))
    except Exception as exc:  # noqa: BLE001
        result_queue.put(("error", str(exc)))


# ============================================================================
# Matplotlib figure helpers
# ============================================================================
def make_3d_figure():
    fig = Figure(figsize=(7.2, 5.6), facecolor=DARK_BG)
    ax = fig.add_subplot(111, projection="3d")
    return fig, ax


def make_2d_figure():
    fig = Figure(figsize=(7.2, 2.1), facecolor=DARK_BG)
    ax = fig.add_subplot(111)
    return fig, ax


def style_3d_axes(ax):
    ax.set_facecolor(DARK_BG)
    ax.set_xlabel("X — length (mm)", color="#C7CEDD", fontsize=8)
    ax.set_ylabel("Y (mm)", color="#C7CEDD", fontsize=8)
    ax.set_zlabel("Z (mm)", color="#C7CEDD", fontsize=8)
    ax.tick_params(colors="#8B93A8", labelsize=7)
    for pane in (ax.xaxis.pane, ax.yaxis.pane, ax.zaxis.pane):
        pane.set_facecolor((0.06, 0.07, 0.11, 1.0))
    ax.set_title("3-D Geometry Preview", color="#F1F5F9", fontsize=10)


def style_2d_axes(ax):
    ax.set_facecolor(PANEL_BG)
    ax.tick_params(colors="#8B93A8", labelsize=7)
    for spine in ax.spines.values():
        spine.set_color("#2A3040")


def draw_geometry(ax3d, ax2d, nose, body, fins, wireframe, baseline_geo=None):
    ax3d.clear()
    style_3d_axes(ax3d)

    def draw(surf, color, alpha):
        X, Y, Z = surf
        if wireframe:
            ax3d.plot_wireframe(X, Y, Z, color=color, linewidth=0.4, alpha=alpha)
        else:
            ax3d.plot_surface(X, Y, Z, color=color, alpha=alpha, linewidth=0, antialiased=True)

    draw(nose, "#3B82F6", 0.9)
    draw(body, "#06B6D4", 0.9)
    for fin in fins:
        draw(fin, "#F59E0B", 0.95)

    if baseline_geo is not None:
        bnose, bbody, bfins, _ = baseline_geo
        for surf in [bnose, bbody] + list(bfins):
            X, Y, Z = surf
            ax3d.plot_wireframe(X, Y, Z, color="#9CA3AF", linewidth=0.35, alpha=0.45)

    all_x = np.concatenate([nose[0].ravel(), body[0].ravel()] + [f[0].ravel() for f in fins])
    span = max(all_x.max() - all_x.min(), 1.0)
    ax3d.set_box_aspect((span, span * 0.45, span * 0.45))

    stations, areas = area_distribution(nose, body)
    ax2d.clear()
    style_2d_axes(ax2d)
    ax2d.fill_between(stations, areas, color="#3B82F6", alpha=0.25)
    ax2d.plot(stations, areas, color="#60A5FA", linewidth=1.6)
    if baseline_geo is not None:
        bstations, bareas = area_distribution(baseline_geo[0], baseline_geo[1])
        ax2d.plot(bstations, bareas, color="#9CA3AF", linewidth=1.2, linestyle="--")
    ax2d.set_xlabel("Axial station (mm)", color="#C7CEDD", fontsize=7)
    ax2d.set_ylabel("Area (mm²)", color="#C7CEDD", fontsize=7)
    ax2d.set_title("Cross-Sectional Area Distribution (Area Rule)", color="#93C5FD", fontsize=8)


# ============================================================================
# Embedded matplotlib canvas helper (tkinter <-> PySimpleGUI bridge)
# ============================================================================
def draw_figure(canvas_elem_tk, figure):
    figure_canvas_agg = FigureCanvasTkAgg(figure, canvas_elem_tk)
    figure_canvas_agg.draw()
    figure_canvas_agg.get_tk_widget().pack(side="top", fill="both", expand=1)
    return figure_canvas_agg


def attach_toolbar(canvas_toolbar_tk, figure_canvas_agg):
    toolbar = NavigationToolbar2Tk(figure_canvas_agg, canvas_toolbar_tk)
    toolbar.update()


# ============================================================================
# Layout builders
# ============================================================================
def field_row(label, key, mn, mx, step, decimals, tooltip, default):
    fmt = f"%.{decimals}f"
    return [
        sg.Text(label, size=(20, 1), tooltip=tooltip),
        sg.Slider(range=(mn, mx), default_value=default, resolution=step,
                  orientation="h", size=(22, 15), key=f"SLD_{key}",
                  enable_events=True, tooltip=tooltip),
        sg.Input(fmt % default, size=(9, 1), key=f"IN_{key}", enable_events=True),
    ]


def build_param_tab(fields, params):
    rows = []
    for label, key, mn, mx, step, decimals, tooltip in fields:
        rows.append(field_row(label, key, mn, mx, step, decimals, tooltip, params.get(key, mn)))
    return sg.Column(rows, scrollable=True, vertical_scroll_only=True,
                      size=(430, 460), background_color=PANEL_BG)


def build_layout():
    params = dict(BUILTIN_PRESETS["Default (cruciform)"])

    preset_row = [
        sg.Text("Preset Library:"),
        sg.Combo(list(BUILTIN_PRESETS.keys()), default_value="Default (cruciform)",
                 key="PRESET_COMBO", size=(30, 1), readonly=True),
        sg.Button("Load Preset", key="LOAD_PRESET"),
    ]

    file_row = [
        sg.Button("Open Preset…", key="OPEN_PRESET"),
        sg.Button("Save Preset…", key="SAVE_PRESET"),
        sg.Button("Reset Defaults", key="RESET"),
    ]

    export_row = [
        sg.Button("Export PNG…", key="EXPORT_PNG"),
        sg.Button("Export HTML…", key="EXPORT_HTML"),
        sg.Button("Export STL…", key="EXPORT_STL", button_color=("white", "#2563EB")),
    ]

    layout_row = [
        sg.Text("Fin arrangement:"),
        sg.Combo(["cruciform", "conventional"], default_value=params["layout"],
                 key="LAYOUT_COMBO", size=(15, 1), readonly=True, enable_events=True),
        sg.Checkbox("Wireframe mode", key="WIREFRAME", enable_events=True),
    ]

    compare_row = [
        sg.Button("Set Current as Baseline", key="SET_BASELINE"),
        sg.Button("Clear Baseline", key="CLEAR_BASELINE"),
        sg.Checkbox("Show baseline overlay", key="SHOW_BASELINE", enable_events=True),
    ]

    tabs = sg.TabGroup([[
        sg.Tab("Fuselage", [[build_param_tab(FUSELAGE_FIELDS, params)]], background_color=PANEL_BG),
        sg.Tab("Wing", [[build_param_tab(WING_FIELDS, params)]], background_color=PANEL_BG),
        sg.Tab("Tail", [[build_param_tab(TAIL_FIELDS, params)]], background_color=PANEL_BG),
    ]])

    left_col = sg.Column([
        preset_row,
        [sg.HorizontalSeparator()],
        [tabs],
        [sg.HorizontalSeparator()],
        layout_row,
        file_row,
        export_row,
        compare_row,
    ], vertical_alignment="top")

    stats_table = sg.Table(
        values=[], headings=["Statistic", "Value"], key="STATS_TABLE",
        auto_size_columns=False, col_widths=[26, 16], num_rows=10,
        justification="left", background_color=PANEL_BG, alternating_row_color="#1B2030",
        text_color="#F1F5F9", header_background_color="#1B2030", header_text_color="#93C5FD",
    )

    right_col = sg.Column([
        [sg.Canvas(key="CANVAS3D_TOOLBAR")],
        [sg.Canvas(key="CANVAS3D", size=(720, 520))],
        [sg.Canvas(key="CANVAS2D", size=(720, 190))],
        [stats_table],
    ], vertical_alignment="top")

    status_bar = [sg.StatusBar("Ready", key="STATUS", size=(80, 1))]

    layout = [
        [sg.Menu([
            ["&File", ["New (reset defaults)", "Open Preset…", "Save Preset", "Save Preset As…",
                        "---", "Export PNG…", "Export HTML…", "Export STL…", "---", "Exit"]],
            ["&View", ["Toggle Wireframe", "Reset Camera"]],
            ["&Compare", ["Set Current as Baseline", "Clear Baseline"]],
            ["&Help", ["About"]],
        ])],
        [left_col, sg.VerticalSeparator(), right_col],
        status_bar,
    ]
    return layout, params


# ============================================================================
# Main application
# ============================================================================
class App:
    def __init__(self):
        layout, self.params = build_layout()
        try:
            self.window = sg.Window(APP_TITLE, layout, finalize=True, resizable=True,
                                      background_color=DARK_BG)
        except Exception as exc:  # noqa: BLE001
            print(f"[aero_body_gui] PySimpleGUI version: {getattr(sg, 'version', 'unknown')}")
            print("[aero_body_gui] Window creation failed. This usually means the "
                  "installed PySimpleGUI version doesn't support a layout option used "
                  "here. Try: pip install --upgrade PySimpleGUI")
            raise

        self.fig3d, self.ax3d = make_3d_figure()
        self.fig2d, self.ax2d = make_2d_figure()

        self.canvas3d_agg = draw_figure(self.window["CANVAS3D"].TKCanvas, self.fig3d)
        attach_toolbar(self.window["CANVAS3D_TOOLBAR"].TKCanvas, self.canvas3d_agg)
        self.canvas2d_agg = draw_figure(self.window["CANVAS2D"].TKCanvas, self.fig2d)

        self.current_geo = None
        self.baseline_geo = None
        self.current_file: Optional[str] = None
        self.stl_queue: "queue.Queue" = queue.Queue()
        self.stl_progress_win = None

        self.set_all_fields(self.params)
        self.recompute_and_render()

    # ------------------------------------------------------------------
    def set_all_fields(self, params: Dict[str, Any]):
        for label, key, mn, mx, step, decimals, tooltip in ALL_FIELDS:
            val = params.get(key, mn)
            self.window[f"SLD_{key}"].update(value=val)
            self.window[f"IN_{key}"].update(value=f"%.{decimals}f" % val)
        self.window["LAYOUT_COMBO"].update(value=params.get("layout", "cruciform"))

    def collect_params(self) -> Dict[str, Any]:
        p: Dict[str, Any] = {}
        for label, key, mn, mx, step, decimals, tooltip in ALL_FIELDS:
            try:
                p[key] = float(self.window[f"IN_{key}"].get())
            except (TypeError, ValueError):
                p[key] = self.window[f"SLD_{key}"].get()
        p["layout"] = self.window["LAYOUT_COMBO"].get()
        p["nose_diameter"] = p["body_diameter"]
        return p

    def set_status(self, msg: str):
        self.window["STATUS"].update(msg)

    # ------------------------------------------------------------------
    def recompute_and_render(self):
        params = self.collect_params()
        try:
            nose, body, fins, stats = build_geometry(params)
        except ValueError as exc:
            self.set_status(f"⚠ Invalid parameter: {exc}")
            return
        except Exception as exc:  # noqa: BLE001
            self.set_status(f"⚠ Error building geometry: {exc}")
            return

        self.params = params
        self.current_geo = (nose, body, fins, stats)
        self.render()
        self.update_stats_table(stats)
        self.set_status("Ready")

    def render(self):
        if self.current_geo is None:
            return
        nose, body, fins, _ = self.current_geo
        wireframe = bool(self.window["WIREFRAME"].get())
        show_baseline = bool(self.window["SHOW_BASELINE"].get())
        baseline = self.baseline_geo if (show_baseline and self.baseline_geo is not None) else None

        draw_geometry(self.ax3d, self.ax2d, nose, body, fins, wireframe, baseline)
        self.fig3d.tight_layout()
        self.fig2d.tight_layout()
        self.canvas3d_agg.draw()
        self.canvas2d_agg.draw()

    def update_stats_table(self, stats: Dict[str, Any]):
        rows = []
        for k, v in stats.items():
            val_str = f"{v:.4g}" if isinstance(v, (int, float)) else str(v)
            rows.append([k, val_str])
        self.window["STATS_TABLE"].update(values=rows)

    def reset_camera(self):
        self.ax3d.view_init(elev=18, azim=-60)
        self.canvas3d_agg.draw()

    # ------------------------------------------------------------------
    # Preset / file actions
    # ------------------------------------------------------------------
    def load_params(self, params: Dict[str, Any]):
        if params.get("nose_diameter") in (None, 0):
            params["nose_diameter"] = params["body_diameter"]
        self.set_all_fields(params)
        self.recompute_and_render()

    def on_load_builtin_preset(self):
        name = self.window["PRESET_COMBO"].get()
        if name in BUILTIN_PRESETS:
            self.load_params(dict(BUILTIN_PRESETS[name]))
            self.set_status(f"Loaded preset: {name}")

    def on_open_preset(self):
        path = sg.popup_get_file("Open Preset", file_types=(("JSON Files", "*.json"),),
                                  no_window=True)
        if not path:
            return
        try:
            with open(path) as f:
                params = json.load(f)
            self.load_params(params)
            self.current_file = path
            self.set_status(f"Opened {os.path.basename(path)}")
        except Exception as exc:  # noqa: BLE001
            sg.popup_error("Open Failed", str(exc))

    def on_save_preset(self, save_as: bool = False):
        path = self.current_file
        if save_as or not path:
            path = sg.popup_get_file("Save Preset As", save_as=True, default_extension=".json",
                                      file_types=(("JSON Files", "*.json"),), no_window=True)
        if not path:
            return
        try:
            with open(path, "w") as f:
                json.dump(self.collect_params(), f, indent=2)
            self.current_file = path
            self.set_status(f"Saved {os.path.basename(path)}")
        except Exception as exc:  # noqa: BLE001
            sg.popup_error("Save Failed", str(exc))

    # ------------------------------------------------------------------
    # Export actions
    # ------------------------------------------------------------------
    def on_export_png(self):
        if self.current_geo is None:
            return
        path = sg.popup_get_file("Export PNG", save_as=True, default_extension=".png",
                                  file_types=(("PNG Files", "*.png"),), no_window=True)
        if not path:
            return
        nose, body, fins, _ = self.current_geo
        try:
            ab.plot_matplotlib(nose, body, fins, path, show=False)
            self.set_status(f"Exported PNG -> {path}")
        except Exception as exc:  # noqa: BLE001
            sg.popup_error("Export Failed", str(exc))

    def on_export_html(self):
        if self.current_geo is None:
            return
        if not ab._HAS_PLOTLY:
            sg.popup_ok("Plotly Not Installed",
                        "Install plotly to enable interactive HTML export:\n\npip install plotly")
            return
        path = sg.popup_get_file("Export HTML", save_as=True, default_extension=".html",
                                  file_types=(("HTML Files", "*.html"),), no_window=True)
        if not path:
            return
        nose, body, fins, stats = self.current_geo
        try:
            ab.plot_plotly(nose, body, fins, path, stats)
            self.set_status(f"Exported interactive HTML -> {path}")
        except Exception as exc:  # noqa: BLE001
            sg.popup_error("Export Failed", str(exc))

    def on_export_stl(self):
        if self.current_geo is None:
            return
        path = sg.popup_get_file("Export STL", save_as=True, default_extension=".stl",
                                  file_types=(("STL Files", "*.stl"),), no_window=True)
        if not path:
            return
        nose, body, fins, _ = self.current_geo

        self.stl_progress_win = sg.Window("Exporting STL…", [
            [sg.Text("Building triangle mesh and writing STL file…")],
            [sg.ProgressBar(100, orientation="h", size=(40, 20), key="PROGRESS")],
        ], finalize=True, modal=True)

        t = threading.Thread(target=stl_export_thread,
                              args=(nose, body, fins, path, self.stl_queue), daemon=True)
        t.start()

    def poll_stl_queue(self):
        if self.stl_progress_win is None:
            return
        try:
            while True:
                kind, payload = self.stl_queue.get_nowait()
                if kind == "progress":
                    self.stl_progress_win["PROGRESS"].update(payload)
                elif kind == "done":
                    self.stl_progress_win.close()
                    self.stl_progress_win = None
                    self.set_status(f"Exported STL -> {payload}")
                elif kind == "error":
                    self.stl_progress_win.close()
                    self.stl_progress_win = None
                    sg.popup_error("STL Export Failed", payload)
        except queue.Empty:
            pass

    # ------------------------------------------------------------------
    # Comparison / baseline
    # ------------------------------------------------------------------
    def on_set_baseline(self):
        if self.current_geo is None:
            return
        self.baseline_geo = self.current_geo
        self.window["SHOW_BASELINE"].update(value=True)
        self.set_status("Baseline set from current geometry")
        self.render()

    def on_clear_baseline(self):
        self.baseline_geo = None
        self.window["SHOW_BASELINE"].update(value=False)
        self.render()
        self.set_status("Baseline cleared")

    def on_about(self):
        sg.popup_ok(
            "About",
            f"{APP_TITLE}\n\n"
            "A parametric 3-D geometry studio for streamlined bodies "
            "(nose + fuselage + fin panels), built on the aero_body "
            "surface-generation engine.\n\n"
            "Features: live 3-D preview, area-rule cross-section chart, "
            "STL export, JSON presets, and baseline comparison overlays.")

    # ------------------------------------------------------------------
    # Event loop
    # ------------------------------------------------------------------
    def sync_slider_and_input(self, event, values):
        """Keep the slider and its numeric text box in sync for whichever
        one the user just touched."""
        if event.startswith("SLD_"):
            key = event[4:]
            for label, k, mn, mx, step, decimals, tooltip in ALL_FIELDS:
                if k == key:
                    self.window[f"IN_{key}"].update(value=f"%.{decimals}f" % values[event])
                    break
        elif event.startswith("IN_"):
            key = event[3:]
            try:
                val = float(values[event])
            except ValueError:
                return
            self.window[f"SLD_{key}"].update(value=val)

    def run(self):
        while True:
            event, values = self.window.read(timeout=100)

            if event in (sg.WIN_CLOSED, "Exit"):
                break

            self.poll_stl_queue()

            if event == "__TIMEOUT__":
                continue

            if event.startswith("SLD_") or event.startswith("IN_"):
                self.sync_slider_and_input(event, values)
                self.recompute_and_render()
            elif event in ("LAYOUT_COMBO", "WIREFRAME", "SHOW_BASELINE"):
                self.recompute_and_render()
            elif event == "LOAD_PRESET":
                self.on_load_builtin_preset()
            elif event in ("RESET", "New (reset defaults)"):
                self.load_params(dict(BUILTIN_PRESETS["Default (cruciform)"]))
                self.current_file = None
                self.set_status("Reset to defaults")
            elif event in ("OPEN_PRESET", "Open Preset…"):
                self.on_open_preset()
            elif event in ("SAVE_PRESET", "Save Preset"):
                self.on_save_preset(save_as=False)
            elif event == "Save Preset As…":
                self.on_save_preset(save_as=True)
            elif event in ("EXPORT_PNG", "Export PNG…"):
                self.on_export_png()
            elif event in ("EXPORT_HTML", "Export HTML…"):
                self.on_export_html()
            elif event in ("EXPORT_STL", "Export STL…"):
                self.on_export_stl()
            elif event == "Toggle Wireframe":
                self.window["WIREFRAME"].update(value=not self.window["WIREFRAME"].get())
                self.render()
            elif event == "Reset Camera":
                self.reset_camera()
            elif event in ("SET_BASELINE", "Set Current as Baseline"):
                self.on_set_baseline()
            elif event in ("CLEAR_BASELINE", "Clear Baseline"):
                self.on_clear_baseline()
            elif event == "About":
                self.on_about()

        self.window.close()


def main():
    app = App()
    app.run()


if __name__ == "__main__":
    main()
